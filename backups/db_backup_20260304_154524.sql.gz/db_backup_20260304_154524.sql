--
-- PostgreSQL database dump
--

\restrict GNkzTv6r4IxEzEceiR8561LVXhUKLlcgxJ2SdEA1SL6wfA2rA5lokCvbzBXNAbS

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: attendancestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.attendancestatus AS ENUM (
    'PRESENT',
    'ABSENT',
    'SICK',
    'LATE',
    'present',
    'absent',
    'late',
    'excused'
);


ALTER TYPE public.attendancestatus OWNER TO postgres;

--
-- Name: bookingstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.bookingstatus AS ENUM (
    'pending',
    'confirmed',
    'cancelled',
    'completed'
);


ALTER TYPE public.bookingstatus OWNER TO postgres;

--
-- Name: chattype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.chattype AS ENUM (
    'announcement',
    'group_chat',
    'direct',
    'support',
    'schedule_notification',
    'system'
);


ALTER TYPE public.chattype OWNER TO postgres;

--
-- Name: eventtype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.eventtype AS ENUM (
    'TRAINING',
    'GAME',
    'MEDICAL'
);


ALTER TYPE public.eventtype OWNER TO postgres;

--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.paymentmethod AS ENUM (
    'CASH',
    'CARD',
    'TRANSFER',
    'cash',
    'card',
    'bank_transfer',
    'online'
);


ALTER TYPE public.paymentmethod OWNER TO postgres;

--
-- Name: posttype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.posttype AS ENUM (
    'NEWS',
    'ANNOUNCEMENT',
    'SCHEDULE',
    'MATCH_REPORT',
    'EVENT'
);


ALTER TYPE public.posttype OWNER TO postgres;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.userrole AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'COACH',
    'PARENT',
    'super_admin',
    'admin',
    'coach',
    'parent',
    'owner',
    'accountant'
);


ALTER TYPE public.userrole OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: absence_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.absence_requests (
    id integer NOT NULL,
    student_id integer NOT NULL,
    requested_by integer NOT NULL,
    absence_date date NOT NULL,
    reason character varying(500),
    status character varying(20),
    approved_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.absence_requests OWNER TO postgres;

--
-- Name: absence_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.absence_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absence_requests_id_seq OWNER TO postgres;

--
-- Name: absence_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.absence_requests_id_seq OWNED BY public.absence_requests.id;


--
-- Name: achievements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.achievements (
    id integer NOT NULL,
    student_id integer,
    title character varying(200),
    description character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    icon character varying,
    type character varying,
    is_viewed boolean
);


ALTER TABLE public.achievements OWNER TO postgres;

--
-- Name: achievements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.achievements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.achievements_id_seq OWNER TO postgres;

--
-- Name: achievements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.achievements_id_seq OWNED BY public.achievements.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: announcement_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement_reads (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone,
    confirmed boolean,
    confirmed_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.announcement_reads OWNER TO postgres;

--
-- Name: announcement_reads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcement_reads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcement_reads_id_seq OWNER TO postgres;

--
-- Name: announcement_reads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcement_reads_id_seq OWNED BY public.announcement_reads.id;


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    event_id integer,
    student_id integer,
    status public.attendancestatus,
    mark integer,
    parent_rating integer,
    parent_feedback character varying(500)
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendances_id_seq OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer NOT NULL,
    entity_name character varying(255),
    action character varying(20) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_fields character varying[],
    user_id integer,
    user_name character varying(255),
    reason character varying(500),
    ip_address character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    parent_user_id integer NOT NULL,
    student_id integer NOT NULL,
    coach_id integer,
    event_id integer,
    booking_date timestamp with time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    location character varying(200),
    status public.bookingstatus DEFAULT 'pending'::public.bookingstatus NOT NULL,
    notes text,
    parent_notes text,
    admin_notes text,
    price integer,
    is_paid integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: coach_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coach_recommendations (
    id integer NOT NULL,
    student_id integer NOT NULL,
    coach_id integer NOT NULL,
    recommendation_type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    priority character varying(20),
    target_date date,
    is_completed boolean,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.coach_recommendations OWNER TO postgres;

--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coach_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coach_recommendations_id_seq OWNER TO postgres;

--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coach_recommendations_id_seq OWNED BY public.coach_recommendations.id;


--
-- Name: employee_contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_contracts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_type character varying DEFAULT 'fixed'::character varying,
    base_salary double precision DEFAULT '0'::double precision,
    per_student_rate double precision DEFAULT '0'::double precision,
    per_training_rate double precision DEFAULT '0'::double precision,
    advance_percent double precision DEFAULT '40'::double precision,
    advance_day integer DEFAULT 25,
    salary_day integer DEFAULT 10,
    effective_from date NOT NULL,
    effective_to date,
    is_active boolean DEFAULT true,
    notes character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by_id integer,
    rates json
);


ALTER TABLE public.employee_contracts OWNER TO postgres;

--
-- Name: employee_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_contracts_id_seq OWNER TO postgres;

--
-- Name: employee_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_contracts_id_seq OWNED BY public.employee_contracts.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    group_id integer,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    type public.eventtype,
    location character varying,
    opponent_team character varying(200),
    home_away character varying(10),
    score_home integer,
    score_away integer,
    meeting_time timestamp without time zone,
    departure_time timestamp without time zone,
    transport_info character varying,
    uniform_color character varying(50),
    equipment_required character varying,
    student_id integer,
    status character varying DEFAULT 'scheduled'::character varying,
    notes character varying,
    training_plan character varying
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: COLUMN events.opponent_team; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.opponent_team IS 'Название команды противника';


--
-- Name: COLUMN events.home_away; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.home_away IS 'home/away/neutral';


--
-- Name: COLUMN events.score_home; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.score_home IS 'Наши голы';


--
-- Name: COLUMN events.score_away; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.score_away IS 'Голы противника';


--
-- Name: COLUMN events.meeting_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.meeting_time IS 'Время сбора команды';


--
-- Name: COLUMN events.departure_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.departure_time IS 'Время выезда';


--
-- Name: COLUMN events.transport_info; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.transport_info IS 'Информация о транспорте';


--
-- Name: COLUMN events.uniform_color; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.uniform_color IS 'Цвет формы (основная/запасная)';


--
-- Name: COLUMN events.equipment_required; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.equipment_required IS 'Необходимое оборудование';


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    amount double precision NOT NULL,
    description character varying(1000),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    title character varying(200) NOT NULL,
    category character varying,
    date date NOT NULL,
    created_by_id integer,
    marketing_campaign_id integer
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expenses_id_seq OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: freeze_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.freeze_requests (
    id integer NOT NULL,
    student_id integer NOT NULL,
    requested_by_id integer,
    start_date date,
    end_date date NOT NULL,
    reason character varying(500),
    file_url character varying,
    status character varying,
    created_at timestamp without time zone,
    processed_at timestamp without time zone,
    processed_by_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.freeze_requests OWNER TO postgres;

--
-- Name: freeze_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.freeze_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.freeze_requests_id_seq OWNER TO postgres;

--
-- Name: freeze_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.freeze_requests_id_seq OWNED BY public.freeze_requests.id;


--
-- Name: funnel_stages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funnel_stages (
    id integer NOT NULL,
    key character varying NOT NULL,
    title character varying NOT NULL,
    color character varying,
    "order" integer,
    is_system boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.funnel_stages OWNER TO postgres;

--
-- Name: funnel_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funnel_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funnel_stages_id_seq OWNER TO postgres;

--
-- Name: funnel_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funnel_stages_id_seq OWNED BY public.funnel_stages.id;


--
-- Name: generated_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generated_events (
    id integer NOT NULL,
    template_id integer NOT NULL,
    event_id integer NOT NULL,
    original_date timestamp without time zone NOT NULL,
    is_modified boolean,
    is_cancelled boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.generated_events OWNER TO postgres;

--
-- Name: generated_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generated_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generated_events_id_seq OWNER TO postgres;

--
-- Name: generated_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generated_events_id_seq OWNED BY public.generated_events.id;


--
-- Name: group_chat_read_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_chat_read_status (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    last_read_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.group_chat_read_status OWNER TO postgres;

--
-- Name: group_chat_read_status_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.group_chat_read_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_chat_read_status_id_seq OWNER TO postgres;

--
-- Name: group_chat_read_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.group_chat_read_status_id_seq OWNED BY public.group_chat_read_status.id;


--
-- Name: group_coaches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_coaches (
    group_id integer NOT NULL,
    coach_id integer NOT NULL
);


ALTER TABLE public.group_coaches OWNER TO postgres;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    name character varying,
    coach_id integer,
    max_capacity integer,
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    age_group character varying,
    subscription_type character varying DEFAULT 'by_class'::character varying,
    monthly_fee double precision DEFAULT 0.0,
    classes_per_month integer DEFAULT 8,
    payment_due_day integer DEFAULT 10
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: hr_candidates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hr_candidates (
    id integer NOT NULL,
    full_name character varying NOT NULL,
    target_role character varying,
    phone character varying,
    email character varying,
    experience_years double precision,
    experience_summary text,
    stage character varying,
    next_interview_at timestamp without time zone,
    notes text,
    resume_url character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.hr_candidates OWNER TO postgres;

--
-- Name: hr_candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hr_candidates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hr_candidates_id_seq OWNER TO postgres;

--
-- Name: hr_candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hr_candidates_id_seq OWNED BY public.hr_candidates.id;


--
-- Name: hr_funnel_stages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hr_funnel_stages (
    id integer NOT NULL,
    key character varying NOT NULL,
    title character varying NOT NULL,
    color character varying,
    "order" integer,
    is_system boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.hr_funnel_stages OWNER TO postgres;

--
-- Name: hr_funnel_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hr_funnel_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hr_funnel_stages_id_seq OWNER TO postgres;

--
-- Name: hr_funnel_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hr_funnel_stages_id_seq OWNED BY public.hr_funnel_stages.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id integer NOT NULL,
    payment_id integer NOT NULL,
    item_type character varying NOT NULL,
    description character varying(500) NOT NULL,
    quantity integer NOT NULL,
    unit_price double precision NOT NULL,
    total_price double precision NOT NULL,
    service_date timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_items_id_seq OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: lead_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_tasks (
    id integer NOT NULL,
    lead_id integer NOT NULL,
    title character varying NOT NULL,
    due_date timestamp without time zone,
    completed boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.lead_tasks OWNER TO postgres;

--
-- Name: lead_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_tasks_id_seq OWNER TO postgres;

--
-- Name: lead_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_tasks_id_seq OWNED BY public.lead_tasks.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    name character varying,
    phone character varying,
    age integer,
    next_contact_date timestamp without time zone,
    status character varying,
    source character varying,
    notes character varying,
    rejection_reason character varying,
    first_call_at timestamp without time zone,
    first_trial_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by_id integer,
    responsible_id integer
);


ALTER TABLE public.leads OWNER TO postgres;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_id_seq OWNER TO postgres;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: marketing_campaigns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_campaigns (
    id integer NOT NULL,
    name character varying NOT NULL,
    status character varying,
    budget double precision,
    spend double precision,
    leads integer,
    paying_students integer,
    revenue double precision,
    source character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.marketing_campaigns OWNER TO postgres;

--
-- Name: marketing_campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_campaigns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.marketing_campaigns_id_seq OWNER TO postgres;

--
-- Name: marketing_campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_campaigns_id_seq OWNED BY public.marketing_campaigns.id;


--
-- Name: media_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_reports (
    id integer NOT NULL,
    event_id integer,
    url character varying,
    type character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.media_reports OWNER TO postgres;

--
-- Name: media_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_reports_id_seq OWNER TO postgres;

--
-- Name: media_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_reports_id_seq OWNED BY public.media_reports.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    updated_at timestamp without time zone,
    id integer NOT NULL,
    sender_id integer,
    recipient_id integer,
    content text NOT NULL,
    created_at timestamp without time zone,
    is_read boolean,
    group_id integer,
    chat_type public.chattype DEFAULT 'announcement'::public.chattype,
    is_pinned boolean,
    poll_id integer,
    is_general boolean DEFAULT false
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payment_reminders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_reminders (
    id integer NOT NULL,
    student_id integer NOT NULL,
    reminder_type character varying(50) NOT NULL,
    sent_at timestamp without time zone,
    sent_via character varying(20) NOT NULL,
    target_month date NOT NULL,
    amount_due double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.payment_reminders OWNER TO postgres;

--
-- Name: payment_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_reminders_id_seq OWNER TO postgres;

--
-- Name: payment_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_reminders_id_seq OWNED BY public.payment_reminders.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    student_id integer,
    amount double precision,
    payment_date date,
    payment_period date,
    method public.paymentmethod,
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    last_student_name character varying(255),
    status character varying DEFAULT 'completed'::character varying,
    description character varying,
    reference_id character varying
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: physical_tests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.physical_tests (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    unit character varying,
    category character varying,
    min_age integer,
    max_age integer,
    is_active boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.physical_tests OWNER TO postgres;

--
-- Name: physical_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.physical_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.physical_tests_id_seq OWNER TO postgres;

--
-- Name: physical_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.physical_tests_id_seq OWNED BY public.physical_tests.id;


--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_votes (
    id integer NOT NULL,
    poll_id integer,
    user_id integer,
    option_index integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.poll_votes OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_votes_id_seq OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_votes_id_seq OWNED BY public.poll_votes.id;


--
-- Name: polls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.polls (
    id integer NOT NULL,
    creator_id integer,
    group_id integer,
    question character varying(500) NOT NULL,
    options json NOT NULL,
    is_anonymous boolean,
    is_multiple_choice boolean,
    ends_at timestamp without time zone,
    created_at timestamp without time zone,
    is_closed boolean,
    updated_at timestamp without time zone
);


ALTER TABLE public.polls OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.polls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.polls_id_seq OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.polls_id_seq OWNED BY public.polls.id;


--
-- Name: post_reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_reactions (
    id integer NOT NULL,
    post_id integer,
    user_id integer,
    reaction_type character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.post_reactions OWNER TO postgres;

--
-- Name: post_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_reactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_reactions_id_seq OWNER TO postgres;

--
-- Name: post_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_reactions_id_seq OWNED BY public.post_reactions.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    author_id integer,
    group_id integer,
    post_type public.posttype,
    title character varying(255),
    content text NOT NULL,
    media_urls json,
    attachments json,
    views_count integer,
    likes_count integer,
    is_pinned boolean,
    is_published boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    requires_confirmation boolean,
    confirmation_deadline timestamp without time zone
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    endpoint text NOT NULL,
    p256dh character varying NOT NULL,
    auth character varying NOT NULL,
    user_agent character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.push_subscriptions OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.push_subscriptions_id_seq OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: salary_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salary_payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount double precision NOT NULL,
    payment_type character varying DEFAULT 'salary'::character varying,
    payment_date date NOT NULL,
    period_month integer NOT NULL,
    period_year integer NOT NULL,
    method character varying DEFAULT 'cash'::character varying,
    status character varying DEFAULT 'completed'::character varying,
    description character varying(500),
    reference_id character varying(100),
    calculated_base double precision,
    calculated_students integer,
    calculated_trainings integer,
    created_at timestamp without time zone,
    created_by_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.salary_payments OWNER TO postgres;

--
-- Name: salary_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salary_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.salary_payments_id_seq OWNER TO postgres;

--
-- Name: salary_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salary_payments_id_seq OWNED BY public.salary_payments.id;


--
-- Name: schedule_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_changes (
    id integer NOT NULL,
    event_id integer,
    group_id integer NOT NULL,
    change_type character varying(30) NOT NULL,
    reason character varying(500) NOT NULL,
    old_start_time timestamp without time zone,
    new_start_time timestamp without time zone,
    old_end_time timestamp without time zone,
    new_end_time timestamp without time zone,
    old_location character varying(200),
    new_location character varying(200),
    changed_by integer,
    notification_sent boolean,
    notification_sent_at timestamp without time zone,
    parents_notified integer,
    coach_notified boolean,
    sms_sent boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.schedule_changes OWNER TO postgres;

--
-- Name: schedule_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_changes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_changes_id_seq OWNER TO postgres;

--
-- Name: schedule_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_changes_id_seq OWNED BY public.schedule_changes.id;


--
-- Name: schedule_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_templates (
    id integer NOT NULL,
    group_id integer NOT NULL,
    name character varying(100) NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_until timestamp without time zone NOT NULL,
    is_active boolean,
    schedule_rules json NOT NULL,
    excluded_dates json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by integer,
    deleted_at timestamp without time zone,
    deletion_reason character varying,
    deleted_by_id integer
);


ALTER TABLE public.schedule_templates OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_templates_id_seq OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_templates_id_seq OWNED BY public.schedule_templates.id;


--
-- Name: school_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.school_settings (
    key character varying(100) NOT NULL,
    value text,
    description character varying(255),
    "group" character varying(50),
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.school_settings OWNER TO postgres;

--
-- Name: season_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.season_summaries (
    id integer NOT NULL,
    student_id integer NOT NULL,
    season_year integer NOT NULL,
    gpa_technique double precision,
    gpa_tactics double precision,
    gpa_physical double precision,
    gpa_discipline double precision,
    total_gpa double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    gpa_speed double precision
);


ALTER TABLE public.season_summaries OWNER TO postgres;

--
-- Name: season_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.season_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.season_summaries_id_seq OWNER TO postgres;

--
-- Name: season_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.season_summaries_id_seq OWNED BY public.season_summaries.id;


--
-- Name: student_group_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_group_history (
    id integer NOT NULL,
    student_id integer,
    group_id integer,
    joined_at date,
    left_at date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.student_group_history OWNER TO postgres;

--
-- Name: student_group_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_group_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_group_history_id_seq OWNER TO postgres;

--
-- Name: student_group_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_group_history_id_seq OWNED BY public.student_group_history.id;


--
-- Name: student_guardians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_guardians (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    student_id integer,
    user_id integer,
    relationship_type character varying
);


ALTER TABLE public.student_guardians OWNER TO postgres;

--
-- Name: student_guardians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_guardians_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_guardians_id_seq OWNER TO postgres;

--
-- Name: student_guardians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_guardians_id_seq OWNED BY public.student_guardians.id;


--
-- Name: student_photos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_photos (
    id integer NOT NULL,
    student_id integer NOT NULL,
    photo_url character varying(500) NOT NULL,
    thumbnail_url character varying(500),
    caption character varying(500),
    training_date date,
    group_id integer,
    uploaded_by integer,
    is_profile_worthy boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.student_photos OWNER TO postgres;

--
-- Name: student_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_photos_id_seq OWNER TO postgres;

--
-- Name: student_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_photos_id_seq OWNED BY public.student_photos.id;


--
-- Name: student_physical_test_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_physical_test_results (
    id integer NOT NULL,
    student_id integer NOT NULL,
    test_id integer NOT NULL,
    value double precision NOT NULL,
    date timestamp without time zone,
    quarter integer NOT NULL,
    year integer NOT NULL,
    coach_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.student_physical_test_results OWNER TO postgres;

--
-- Name: student_physical_test_results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_physical_test_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_physical_test_results_id_seq OWNER TO postgres;

--
-- Name: student_physical_test_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_physical_test_results_id_seq OWNED BY public.student_physical_test_results.id;


--
-- Name: student_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_skills (
    id integer NOT NULL,
    student_id integer NOT NULL,
    rating_month integer NOT NULL,
    rating_year integer NOT NULL,
    technique integer,
    discipline integer,
    coach_comment text,
    rated_by_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tactics integer,
    physical integer,
    speed integer,
    talent_tags json
);


ALTER TABLE public.student_skills OWNER TO postgres;

--
-- Name: student_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_skills_id_seq OWNER TO postgres;

--
-- Name: student_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_skills_id_seq OWNED BY public.student_skills.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    first_name character varying,
    last_name character varying,
    dob date,
    group_id integer,
    avatar_url character varying,
    status character varying,
    balance double precision,
    parent_phone character varying,
    height double precision,
    weight double precision,
    total_paid_cache double precision DEFAULT '0'::double precision,
    cache_updated_at timestamp without time zone,
    blood_type character varying(10),
    allergies text,
    emergency_contact character varying(100),
    emergency_phone character varying(20),
    insurance_number character varying(50),
    individual_fee double precision,
    fee_discount_reason character varying(255),
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    last_parent_name character varying(255),
    last_parent_phone character varying(50),
    last_group_name character varying(255),
    medical_certificate_expires date,
    insurance_expires date,
    medical_certificate_file character varying,
    shoe_size character varying,
    medical_notes text,
    attendance_streak integer,
    subscription_expires date,
    is_debtor boolean DEFAULT false,
    is_frozen boolean DEFAULT false,
    freeze_until date,
    freeze_document_url character varying,
    medical_info character varying,
    "position" character varying,
    dominant_foot character varying,
    tshirt_size character varying,
    notes character varying,
    stars integer DEFAULT 0
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.students_id_seq OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying NOT NULL,
    description text,
    status character varying,
    priority character varying,
    due_date timestamp without time zone,
    assignee_id integer,
    created_by_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: training_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_plans (
    id integer NOT NULL,
    event_id integer,
    coach_id integer,
    objectives text,
    theme character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.training_plans OWNER TO postgres;

--
-- Name: training_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.training_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_plans_id_seq OWNER TO postgres;

--
-- Name: training_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.training_plans_id_seq OWNED BY public.training_plans.id;


--
-- Name: trial_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trial_sessions (
    id integer NOT NULL,
    student_name character varying(200) NOT NULL,
    parent_name character varying(200),
    parent_phone character varying(20) NOT NULL,
    parent_email character varying(100),
    age integer,
    preferred_group_id integer,
    trial_date date NOT NULL,
    status character varying(30),
    source character varying(50),
    notes text,
    converted_student_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.trial_sessions OWNER TO postgres;

--
-- Name: trial_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trial_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trial_sessions_id_seq OWNER TO postgres;

--
-- Name: trial_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trial_sessions_id_seq OWNED BY public.trial_sessions.id;


--
-- Name: user_activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_activity_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    login_time timestamp without time zone DEFAULT now() NOT NULL,
    ip_address character varying(50),
    user_agent character varying(500),
    device_type character varying(20) DEFAULT 'unknown'::character varying,
    platform character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_activity_logs OWNER TO postgres;

--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_activity_logs_id_seq OWNER TO postgres;

--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_activity_logs_id_seq OWNED BY public.user_activity_logs.id;


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    login character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by_id integer,
    updated_by_id integer,
    note text,
    password_encrypted character varying(500) NOT NULL,
    last_viewed_at timestamp with time zone,
    last_viewed_by_id integer,
    view_count integer DEFAULT 0
);


ALTER TABLE public.user_credentials OWNER TO postgres;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_credentials_id_seq OWNER TO postgres;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_credentials_id_seq OWNED BY public.user_credentials.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    phone character varying,
    password_hash character varying,
    full_name character varying,
    role public.userrole,
    avatar_url character varying,
    phone_secondary character varying,
    preferred_language character varying DEFAULT 'ro'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    fcm_token character varying(500),
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    telegram_chat_id character varying,
    can_view_history boolean DEFAULT false NOT NULL,
    can_view_analytics boolean DEFAULT false NOT NULL,
    can_view_crm boolean DEFAULT false NOT NULL,
    can_view_recruitment boolean DEFAULT false NOT NULL,
    can_view_marketing boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: absence_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests ALTER COLUMN id SET DEFAULT nextval('public.absence_requests_id_seq'::regclass);


--
-- Name: achievements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements ALTER COLUMN id SET DEFAULT nextval('public.achievements_id_seq'::regclass);


--
-- Name: announcement_reads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads ALTER COLUMN id SET DEFAULT nextval('public.announcement_reads_id_seq'::regclass);


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: coach_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations ALTER COLUMN id SET DEFAULT nextval('public.coach_recommendations_id_seq'::regclass);


--
-- Name: employee_contracts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts ALTER COLUMN id SET DEFAULT nextval('public.employee_contracts_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: freeze_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests ALTER COLUMN id SET DEFAULT nextval('public.freeze_requests_id_seq'::regclass);


--
-- Name: funnel_stages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funnel_stages ALTER COLUMN id SET DEFAULT nextval('public.funnel_stages_id_seq'::regclass);


--
-- Name: generated_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events ALTER COLUMN id SET DEFAULT nextval('public.generated_events_id_seq'::regclass);


--
-- Name: group_chat_read_status id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_chat_read_status ALTER COLUMN id SET DEFAULT nextval('public.group_chat_read_status_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: hr_candidates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_candidates ALTER COLUMN id SET DEFAULT nextval('public.hr_candidates_id_seq'::regclass);


--
-- Name: hr_funnel_stages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_funnel_stages ALTER COLUMN id SET DEFAULT nextval('public.hr_funnel_stages_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: lead_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tasks ALTER COLUMN id SET DEFAULT nextval('public.lead_tasks_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: marketing_campaigns id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_campaigns ALTER COLUMN id SET DEFAULT nextval('public.marketing_campaigns_id_seq'::regclass);


--
-- Name: media_reports id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_reports ALTER COLUMN id SET DEFAULT nextval('public.media_reports_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payment_reminders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders ALTER COLUMN id SET DEFAULT nextval('public.payment_reminders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: physical_tests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.physical_tests ALTER COLUMN id SET DEFAULT nextval('public.physical_tests_id_seq'::regclass);


--
-- Name: poll_votes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes ALTER COLUMN id SET DEFAULT nextval('public.poll_votes_id_seq'::regclass);


--
-- Name: polls id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls ALTER COLUMN id SET DEFAULT nextval('public.polls_id_seq'::regclass);


--
-- Name: post_reactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions ALTER COLUMN id SET DEFAULT nextval('public.post_reactions_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: salary_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments ALTER COLUMN id SET DEFAULT nextval('public.salary_payments_id_seq'::regclass);


--
-- Name: schedule_changes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes ALTER COLUMN id SET DEFAULT nextval('public.schedule_changes_id_seq'::regclass);


--
-- Name: schedule_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates ALTER COLUMN id SET DEFAULT nextval('public.schedule_templates_id_seq'::regclass);


--
-- Name: season_summaries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries ALTER COLUMN id SET DEFAULT nextval('public.season_summaries_id_seq'::regclass);


--
-- Name: student_group_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_group_history ALTER COLUMN id SET DEFAULT nextval('public.student_group_history_id_seq'::regclass);


--
-- Name: student_guardians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians ALTER COLUMN id SET DEFAULT nextval('public.student_guardians_id_seq'::regclass);


--
-- Name: student_photos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos ALTER COLUMN id SET DEFAULT nextval('public.student_photos_id_seq'::regclass);


--
-- Name: student_physical_test_results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_physical_test_results ALTER COLUMN id SET DEFAULT nextval('public.student_physical_test_results_id_seq'::regclass);


--
-- Name: student_skills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills ALTER COLUMN id SET DEFAULT nextval('public.student_skills_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: training_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans ALTER COLUMN id SET DEFAULT nextval('public.training_plans_id_seq'::regclass);


--
-- Name: trial_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions ALTER COLUMN id SET DEFAULT nextval('public.trial_sessions_id_seq'::regclass);


--
-- Name: user_activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs ALTER COLUMN id SET DEFAULT nextval('public.user_activity_logs_id_seq'::regclass);


--
-- Name: user_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials ALTER COLUMN id SET DEFAULT nextval('public.user_credentials_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: absence_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.absence_requests (id, student_id, requested_by, absence_date, reason, status, approved_by, created_at, updated_at) FROM stdin;
1	1	10	2026-03-04	Семейные обстоятельства	approved	9	2026-03-03 17:37:25.317403	2026-03-03 20:00:03.338964
\.


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.achievements (id, student_id, title, description, created_at, updated_at, icon, type, is_viewed) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
init_db_managed
\.


--
-- Data for Name: announcement_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement_reads (id, post_id, user_id, read_at, confirmed, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (created_at, updated_at, id, event_id, student_id, status, mark, parent_rating, parent_feedback) FROM stdin;
2026-03-03 20:09:32.793785	2026-03-03 20:09:32.793801	1	1	1	PRESENT	\N	\N	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, entity_type, entity_id, entity_name, action, old_data, new_data, changed_fields, user_id, user_name, reason, ip_address, created_at, updated_at) FROM stdin;
1	user	7	Тест Тренер 2	create	null	{"id": 7, "role": "coach", "phone": "+79001112233", "full_name": "Тест Тренер 2", "is_active": true, "avatar_url": null, "created_at": "2026-03-03T19:21:15.101317", "deleted_at": null, "updated_at": "2026-03-03T19:21:15.101336", "can_view_crm": false, "deleted_by_id": null, "deletion_reason": null, "phone_secondary": null, "can_view_history": false, "telegram_chat_id": null, "can_view_analytics": false, "can_view_marketing": false, "preferred_language": "ru", "can_view_recruitment": false}	{id,phone,phone_secondary,full_name,role,avatar_url,is_active,preferred_language,telegram_chat_id,can_view_history,can_view_analytics,can_view_crm,can_view_recruitment,can_view_marketing,deleted_at,deletion_reason,deleted_by_id,created_at,updated_at}	1	Руководитель Sunny	Создан администратором	\N	2026-03-03 19:21:15.121499	2026-03-03 19:21:15.125054
2	user	8	Иван Тренеров	create	null	{"id": 8, "role": "coach", "phone": "+79009998877", "full_name": "Иван Тренеров", "is_active": true, "avatar_url": null, "created_at": "2026-03-03T19:21:32.927187", "deleted_at": null, "updated_at": "2026-03-03T19:21:32.927218", "can_view_crm": false, "deleted_by_id": null, "deletion_reason": null, "phone_secondary": null, "can_view_history": false, "telegram_chat_id": null, "can_view_analytics": false, "can_view_marketing": false, "preferred_language": "ru", "can_view_recruitment": false}	{id,phone,phone_secondary,full_name,role,avatar_url,is_active,preferred_language,telegram_chat_id,can_view_history,can_view_analytics,can_view_crm,can_view_recruitment,can_view_marketing,deleted_at,deletion_reason,deleted_by_id,created_at,updated_at}	1	Руководитель Sunny	Создан администратором	\N	2026-03-03 19:21:32.930261	2026-03-03 19:21:32.934784
3	user	9	Игорь Федорович	create	null	{"id": 9, "role": "coach", "phone": "+37333333333", "full_name": "Игорь Федорович", "is_active": true, "avatar_url": null, "created_at": "2026-03-03T19:22:44.348616", "deleted_at": null, "updated_at": "2026-03-03T19:22:44.348719", "can_view_crm": false, "deleted_by_id": null, "deletion_reason": null, "phone_secondary": null, "can_view_history": false, "telegram_chat_id": null, "can_view_analytics": false, "can_view_marketing": false, "preferred_language": "ru", "can_view_recruitment": false}	{id,phone,phone_secondary,full_name,role,avatar_url,is_active,preferred_language,telegram_chat_id,can_view_history,can_view_analytics,can_view_crm,can_view_recruitment,can_view_marketing,deleted_at,deletion_reason,deleted_by_id,created_at,updated_at}	1	Руководитель Sunny	Создан администратором	\N	2026-03-03 19:22:44.353587	2026-03-03 19:22:44.357833
4	group	1	U15	create	null	{"id": 1, "name": "U15", "coach_id": 9, "age_group": "2015", "created_at": "2026-03-03T19:23:14.340983", "deleted_at": null, "updated_at": "2026-03-03T19:23:14.341039", "monthly_fee": 1200.0, "max_capacity": 20, "deleted_by_id": null, "deletion_reason": null, "payment_due_day": 10, "classes_per_month": 8, "subscription_type": "by_calendar"}	{id,name,age_group,coach_id,subscription_type,monthly_fee,classes_per_month,payment_due_day,max_capacity,deleted_at,deleted_by_id,deletion_reason,created_at,updated_at}	1	Руководитель Sunny	\N	\N	2026-03-03 19:23:14.369766	2026-03-03 19:23:14.370507
6	schedule_template	1	Расписание U15	update	{"id": 1, "name": "Расписание U15", "group_id": 1, "is_active": false, "created_at": "2026-03-03T19:29:38.428332", "created_by": 1, "deleted_at": null, "updated_at": "2026-03-03T19:29:38.428392", "valid_from": "2026-03-03T02:00:00", "valid_until": "2027-03-03T02:00:00", "deleted_by_id": null, "excluded_dates": [], "schedule_rules": [{"day": 0, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}, {"day": 2, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}, {"day": 4, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}], "deletion_reason": null}	{"id": 1, "name": "Расписание U15", "group_id": 1, "is_active": true, "created_at": "2026-03-03T19:29:38.428332", "created_by": 1, "deleted_at": null, "updated_at": "2026-03-03T19:29:53.562228", "valid_from": "2026-03-03T02:00:00", "valid_until": "2027-03-03T02:00:00", "deleted_by_id": null, "excluded_dates": [], "schedule_rules": [{"day": 0, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}, {"day": 2, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}, {"day": 4, "type": "TRAINING", "end_time": "18:30", "location": "", "start_time": "17:00"}], "deletion_reason": null}	{updated_at,is_active}	1	Руководитель Sunny	\N	\N	2026-03-03 19:29:53.571785	2026-03-03 19:29:53.581988
7	user	10	Маша Иванова	create	null	{"id": 10, "role": "parent", "phone": "+3731111111", "full_name": "Маша Иванова", "is_active": true, "avatar_url": null, "created_at": "2026-03-03T19:34:49.841355", "deleted_at": null, "updated_at": "2026-03-03T19:34:49.841755", "can_view_crm": false, "deleted_by_id": null, "deletion_reason": null, "phone_secondary": null, "can_view_history": false, "telegram_chat_id": null, "can_view_analytics": false, "can_view_marketing": false, "preferred_language": "ru", "can_view_recruitment": false}	{id,phone,phone_secondary,full_name,role,avatar_url,is_active,preferred_language,telegram_chat_id,can_view_history,can_view_analytics,can_view_crm,can_view_recruitment,can_view_marketing,deleted_at,deletion_reason,deleted_by_id,created_at,updated_at}	1	Руководитель Sunny	Создан администратором	\N	2026-03-03 19:34:49.846134	2026-03-03 19:34:49.848709
8	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": null, "stars": 0, "height": null, "status": "active", "weight": null, "balance": 0.0, "group_id": 1, "position": null, "allergies": null, "is_debtor": false, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": null, "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T19:34:49.865164", "tshirt_size": null, "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": null, "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 0, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{"id": 1, "dob": "2015-03-04", "notes": null, "stars": 0, "height": null, "status": "active", "weight": null, "balance": 0.0, "group_id": 1, "position": null, "allergies": null, "is_debtor": false, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T19:34:49.865164", "tshirt_size": null, "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": null, "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 0, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{avatar_url}	1	Руководитель Sunny	\N	\N	2026-03-03 19:42:38.775043	2026-03-03 19:42:38.78609
9	user	11	Админ 1	create	null	{"id": 11, "role": "admin", "phone": "+3735555555", "full_name": "Админ 1", "is_active": true, "avatar_url": null, "created_at": "2026-03-03T20:05:43.232448", "deleted_at": null, "updated_at": "2026-03-03T20:05:43.232524", "can_view_crm": false, "deleted_by_id": null, "deletion_reason": null, "phone_secondary": null, "can_view_history": false, "telegram_chat_id": null, "can_view_analytics": false, "can_view_marketing": false, "preferred_language": "ru", "can_view_recruitment": false}	{id,phone,phone_secondary,full_name,role,avatar_url,is_active,preferred_language,telegram_chat_id,can_view_history,can_view_analytics,can_view_crm,can_view_recruitment,can_view_marketing,deleted_at,deletion_reason,deleted_by_id,created_at,updated_at}	1	Руководитель Sunny	Создан администратором	\N	2026-03-03 20:05:43.237452	2026-03-03 20:05:43.24121
10	payment	1	payment #1	create	null	{"id": 1, "amount": 1000.0, "method": "cash", "status": "pending", "created_at": "2026-03-03T20:06:36.933239", "deleted_at": null, "student_id": 1, "updated_at": "2026-03-03T20:06:36.933287", "description": "Абонемент за март 2026", "payment_date": "2026-03-03", "reference_id": null, "deleted_by_id": null, "payment_period": "2026-03-01", "deletion_reason": null, "last_student_name": null}	{id,student_id,amount,payment_date,payment_period,method,status,description,reference_id,deleted_at,deletion_reason,deleted_by_id,last_student_name,created_at,updated_at}	1	Руководитель Sunny	\N	\N	2026-03-03 20:06:36.958889	2026-03-03 20:06:36.959748
11	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": null, "stars": 0, "height": null, "status": "active", "weight": null, "balance": -1000.0, "group_id": 1, "position": null, "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T20:09:32.789095", "tshirt_size": null, "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": null, "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T20:09:32.789095", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{dominant_foot,weight,tshirt_size,notes,height,position}	9	Игорь Федорович	\N	\N	2026-03-03 20:10:15.314159	2026-03-03 20:10:15.322196
12	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T20:10:15.331846", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T20:10:15.331846", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": "2026-09-03"}	{medical_certificate_expires}	1	Sunny	\N	\N	2026-03-03 21:34:38.008608	2026-03-03 21:34:38.014343
13	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:38.024396", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": "2026-09-03"}	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:38.024396", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{medical_certificate_expires}	1	Sunny	\N	\N	2026-03-03 21:34:42.64053	2026-03-03 21:34:42.650709
14	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:42.660398", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:42.660398", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": "2026-09-03"}	{medical_certificate_expires}	1	Sunny	\N	\N	2026-03-03 21:34:45.102515	2026-03-03 21:34:45.104489
15	student	1	Петя Иванов	update	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:45.108266", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": "2026-09-03"}	{"id": 1, "dob": "2015-03-04", "notes": "", "stars": 0, "height": 135.0, "status": "active", "weight": 35.0, "balance": -1000.0, "group_id": 1, "position": "Вратарь", "allergies": null, "is_debtor": true, "is_frozen": false, "last_name": "Иванов", "shoe_size": null, "avatar_url": "/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG", "blood_type": null, "created_at": "2026-03-03T19:34:49.865143", "deleted_at": null, "first_name": "Петя", "updated_at": "2026-03-03T21:34:45.108266", "tshirt_size": "", "freeze_until": null, "medical_info": "", "parent_phone": "+3731111111", "deleted_by_id": null, "dominant_foot": "Правая", "medical_notes": "", "individual_fee": null, "deletion_reason": null, "emergency_phone": null, "last_group_name": null, "cache_updated_at": null, "insurance_number": null, "last_parent_name": null, "total_paid_cache": 0.0, "attendance_streak": 1, "emergency_contact": null, "insurance_expires": null, "last_parent_phone": null, "fee_discount_reason": null, "freeze_document_url": null, "subscription_expires": null, "medical_certificate_file": null, "medical_certificate_expires": null}	{medical_certificate_expires}	1	Sunny	\N	\N	2026-03-03 21:35:10.545232	2026-03-03 21:35:10.548922
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id, parent_user_id, student_id, coach_id, event_id, booking_date, duration_minutes, location, status, notes, parent_notes, admin_notes, price, is_paid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coach_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coach_recommendations (id, student_id, coach_id, recommendation_type, title, description, priority, target_date, is_completed, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_contracts (id, user_id, salary_type, base_salary, per_student_rate, per_training_rate, advance_percent, advance_day, salary_day, effective_from, effective_to, is_active, notes, created_at, updated_at, created_by_id, rates) FROM stdin;
1	11	fixed	7000	0	0	40	25	10	2026-03-03	\N	t		2026-03-03 21:36:22.749356	2026-03-03 21:36:22.749408	1	{}
2	9	fixed	7000	0	0	40	25	10	2026-03-03	\N	t		2026-03-03 21:36:30.707328	2026-03-03 21:36:30.707348	1	{}
3	1	combined	5000	0	0	40	25	10	2026-03-03	\N	t		2026-03-03 21:37:34.29924	2026-03-03 21:37:34.299255	1	{"game": 50.0, "training": 50.0, "tournament": 50.0, "championship": 50.0}
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (created_at, updated_at, id, group_id, start_time, end_time, type, location, opponent_team, home_away, score_home, score_away, meeting_time, departure_time, transport_info, uniform_color, equipment_required, student_id, status, notes, training_plan) FROM stdin;
2026-03-03 19:29:48.191313	2026-03-03 19:29:48.191355	1	1	2026-03-04 17:00:00	2026-03-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.199826	2026-03-03 19:29:48.199847	2	1	2026-03-06 17:00:00	2026-03-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.211187	2026-03-03 19:29:48.211206	3	1	2026-03-09 17:00:00	2026-03-09 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.217217	2026-03-03 19:29:48.217239	4	1	2026-03-11 17:00:00	2026-03-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.222616	2026-03-03 19:29:48.222632	5	1	2026-03-13 17:00:00	2026-03-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.228461	2026-03-03 19:29:48.228475	6	1	2026-03-16 17:00:00	2026-03-16 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.234099	2026-03-03 19:29:48.234114	7	1	2026-03-18 17:00:00	2026-03-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.239482	2026-03-03 19:29:48.239496	8	1	2026-03-20 17:00:00	2026-03-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.244712	2026-03-03 19:29:48.244725	9	1	2026-03-23 17:00:00	2026-03-23 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.250323	2026-03-03 19:29:48.250339	10	1	2026-03-25 17:00:00	2026-03-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.255397	2026-03-03 19:29:48.255413	11	1	2026-03-27 17:00:00	2026-03-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.261439	2026-03-03 19:29:48.261454	12	1	2026-03-30 17:00:00	2026-03-30 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.273391	2026-03-03 19:29:48.273417	13	1	2026-04-01 17:00:00	2026-04-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.280455	2026-03-03 19:29:48.280477	14	1	2026-04-03 17:00:00	2026-04-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.286834	2026-03-03 19:29:48.286853	15	1	2026-04-06 17:00:00	2026-04-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.292483	2026-03-03 19:29:48.292498	16	1	2026-04-08 17:00:00	2026-04-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.298107	2026-03-03 19:29:48.298126	17	1	2026-04-10 17:00:00	2026-04-10 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.30344	2026-03-03 19:29:48.303454	18	1	2026-04-13 17:00:00	2026-04-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.308869	2026-03-03 19:29:48.308886	19	1	2026-04-15 17:00:00	2026-04-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.313968	2026-03-03 19:29:48.313984	20	1	2026-04-17 17:00:00	2026-04-17 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.318743	2026-03-03 19:29:48.318755	21	1	2026-04-20 17:00:00	2026-04-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.324859	2026-03-03 19:29:48.324879	22	1	2026-04-22 17:00:00	2026-04-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.329935	2026-03-03 19:29:48.32995	23	1	2026-04-24 17:00:00	2026-04-24 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.334364	2026-03-03 19:29:48.334377	24	1	2026-04-27 17:00:00	2026-04-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.338926	2026-03-03 19:29:48.338939	25	1	2026-04-29 17:00:00	2026-04-29 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.343525	2026-03-03 19:29:48.343543	26	1	2026-05-01 17:00:00	2026-05-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.349459	2026-03-03 19:29:48.349476	27	1	2026-05-04 17:00:00	2026-05-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.355239	2026-03-03 19:29:48.355257	28	1	2026-05-06 17:00:00	2026-05-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.361241	2026-03-03 19:29:48.361258	29	1	2026-05-08 17:00:00	2026-05-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.366858	2026-03-03 19:29:48.366875	30	1	2026-05-11 17:00:00	2026-05-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.37248	2026-03-03 19:29:48.372498	31	1	2026-05-13 17:00:00	2026-05-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.377986	2026-03-03 19:29:48.378006	32	1	2026-05-15 17:00:00	2026-05-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.383972	2026-03-03 19:29:48.383989	33	1	2026-05-18 17:00:00	2026-05-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.389928	2026-03-03 19:29:48.389951	34	1	2026-05-20 17:00:00	2026-05-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.395379	2026-03-03 19:29:48.395394	35	1	2026-05-22 17:00:00	2026-05-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.40102	2026-03-03 19:29:48.401042	36	1	2026-05-25 17:00:00	2026-05-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.407313	2026-03-03 19:29:48.407328	37	1	2026-05-27 17:00:00	2026-05-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.412885	2026-03-03 19:29:48.4129	38	1	2026-05-29 17:00:00	2026-05-29 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.419113	2026-03-03 19:29:48.41913	39	1	2026-06-01 17:00:00	2026-06-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.425165	2026-03-03 19:29:48.425182	40	1	2026-06-03 17:00:00	2026-06-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.431078	2026-03-03 19:29:48.431096	41	1	2026-06-05 17:00:00	2026-06-05 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.437214	2026-03-03 19:29:48.437231	42	1	2026-06-08 17:00:00	2026-06-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.442937	2026-03-03 19:29:48.442954	43	1	2026-06-10 17:00:00	2026-06-10 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.448709	2026-03-03 19:29:48.448726	44	1	2026-06-12 17:00:00	2026-06-12 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.454438	2026-03-03 19:29:48.454456	45	1	2026-06-15 17:00:00	2026-06-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.460442	2026-03-03 19:29:48.460462	46	1	2026-06-17 17:00:00	2026-06-17 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.46649	2026-03-03 19:29:48.466507	47	1	2026-06-19 17:00:00	2026-06-19 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.472392	2026-03-03 19:29:48.472411	48	1	2026-06-22 17:00:00	2026-06-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.478515	2026-03-03 19:29:48.478534	49	1	2026-06-24 17:00:00	2026-06-24 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.484225	2026-03-03 19:29:48.48424	50	1	2026-06-26 17:00:00	2026-06-26 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.490066	2026-03-03 19:29:48.490085	51	1	2026-06-29 17:00:00	2026-06-29 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.495383	2026-03-03 19:29:48.495396	52	1	2026-07-01 17:00:00	2026-07-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.499103	2026-03-03 19:29:48.499113	53	1	2026-07-03 17:00:00	2026-07-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.50283	2026-03-03 19:29:48.502841	54	1	2026-07-06 17:00:00	2026-07-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.506699	2026-03-03 19:29:48.506708	55	1	2026-07-08 17:00:00	2026-07-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.51052	2026-03-03 19:29:48.51053	56	1	2026-07-10 17:00:00	2026-07-10 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.514554	2026-03-03 19:29:48.514568	57	1	2026-07-13 17:00:00	2026-07-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.518865	2026-03-03 19:29:48.518876	58	1	2026-07-15 17:00:00	2026-07-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.52237	2026-03-03 19:29:48.522388	59	1	2026-07-17 17:00:00	2026-07-17 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.526304	2026-03-03 19:29:48.526314	60	1	2026-07-20 17:00:00	2026-07-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.529916	2026-03-03 19:29:48.529925	61	1	2026-07-22 17:00:00	2026-07-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.534101	2026-03-03 19:29:48.534111	62	1	2026-07-24 17:00:00	2026-07-24 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.53918	2026-03-03 19:29:48.539194	63	1	2026-07-27 17:00:00	2026-07-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.544654	2026-03-03 19:29:48.544668	64	1	2026-07-29 17:00:00	2026-07-29 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.549704	2026-03-03 19:29:48.549719	65	1	2026-07-31 17:00:00	2026-07-31 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.554854	2026-03-03 19:29:48.55487	66	1	2026-08-03 17:00:00	2026-08-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.559904	2026-03-03 19:29:48.559918	67	1	2026-08-05 17:00:00	2026-08-05 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.565539	2026-03-03 19:29:48.565553	68	1	2026-08-07 17:00:00	2026-08-07 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.570121	2026-03-03 19:29:48.570135	69	1	2026-08-10 17:00:00	2026-08-10 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.574923	2026-03-03 19:29:48.574934	70	1	2026-08-12 17:00:00	2026-08-12 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.579657	2026-03-03 19:29:48.579667	71	1	2026-08-14 17:00:00	2026-08-14 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.592594	2026-03-03 19:29:48.592606	72	1	2026-08-17 17:00:00	2026-08-17 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.596134	2026-03-03 19:29:48.596143	73	1	2026-08-19 17:00:00	2026-08-19 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.599462	2026-03-03 19:29:48.599471	74	1	2026-08-21 17:00:00	2026-08-21 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.603873	2026-03-03 19:29:48.603891	75	1	2026-08-24 17:00:00	2026-08-24 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.607783	2026-03-03 19:29:48.607806	76	1	2026-08-26 17:00:00	2026-08-26 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.61166	2026-03-03 19:29:48.61167	77	1	2026-08-28 17:00:00	2026-08-28 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.615239	2026-03-03 19:29:48.61525	78	1	2026-08-31 17:00:00	2026-08-31 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.618558	2026-03-03 19:29:48.618567	79	1	2026-09-02 17:00:00	2026-09-02 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.621976	2026-03-03 19:29:48.621985	80	1	2026-09-04 17:00:00	2026-09-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.625837	2026-03-03 19:29:48.625849	81	1	2026-09-07 17:00:00	2026-09-07 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.629989	2026-03-03 19:29:48.629999	82	1	2026-09-09 17:00:00	2026-09-09 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.633775	2026-03-03 19:29:48.633802	83	1	2026-09-11 17:00:00	2026-09-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.637637	2026-03-03 19:29:48.637646	84	1	2026-09-14 17:00:00	2026-09-14 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.641267	2026-03-03 19:29:48.641276	85	1	2026-09-16 17:00:00	2026-09-16 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.644634	2026-03-03 19:29:48.644644	86	1	2026-09-18 17:00:00	2026-09-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.648156	2026-03-03 19:29:48.64817	87	1	2026-09-21 17:00:00	2026-09-21 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.651665	2026-03-03 19:29:48.651675	88	1	2026-09-23 17:00:00	2026-09-23 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.655149	2026-03-03 19:29:48.655163	89	1	2026-09-25 17:00:00	2026-09-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.659384	2026-03-03 19:29:48.659393	90	1	2026-09-28 17:00:00	2026-09-28 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.662727	2026-03-03 19:29:48.662736	91	1	2026-09-30 17:00:00	2026-09-30 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.665971	2026-03-03 19:29:48.665979	92	1	2026-10-02 17:00:00	2026-10-02 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.669981	2026-03-03 19:29:48.669991	93	1	2026-10-05 17:00:00	2026-10-05 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.673484	2026-03-03 19:29:48.673493	94	1	2026-10-07 17:00:00	2026-10-07 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.677976	2026-03-03 19:29:48.677987	95	1	2026-10-09 17:00:00	2026-10-09 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.68211	2026-03-03 19:29:48.682121	96	1	2026-10-12 17:00:00	2026-10-12 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.685556	2026-03-03 19:29:48.685566	97	1	2026-10-14 17:00:00	2026-10-14 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.68899	2026-03-03 19:29:48.688999	98	1	2026-10-16 17:00:00	2026-10-16 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.692447	2026-03-03 19:29:48.692457	99	1	2026-10-19 17:00:00	2026-10-19 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.695761	2026-03-03 19:29:48.69577	100	1	2026-10-21 17:00:00	2026-10-21 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.69903	2026-03-03 19:29:48.699039	101	1	2026-10-23 17:00:00	2026-10-23 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.702337	2026-03-03 19:29:48.702346	102	1	2026-10-26 17:00:00	2026-10-26 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.705526	2026-03-03 19:29:48.705536	103	1	2026-10-28 17:00:00	2026-10-28 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.709008	2026-03-03 19:29:48.709018	104	1	2026-10-30 17:00:00	2026-10-30 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.712434	2026-03-03 19:29:48.712443	105	1	2026-11-02 17:00:00	2026-11-02 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.717594	2026-03-03 19:29:48.717606	106	1	2026-11-04 17:00:00	2026-11-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.722568	2026-03-03 19:29:48.722586	107	1	2026-11-06 17:00:00	2026-11-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.727184	2026-03-03 19:29:48.727199	108	1	2026-11-09 17:00:00	2026-11-09 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.731148	2026-03-03 19:29:48.731157	109	1	2026-11-11 17:00:00	2026-11-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.735143	2026-03-03 19:29:48.735153	110	1	2026-11-13 17:00:00	2026-11-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.73898	2026-03-03 19:29:48.738989	111	1	2026-11-16 17:00:00	2026-11-16 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.742893	2026-03-03 19:29:48.742906	112	1	2026-11-18 17:00:00	2026-11-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.746116	2026-03-03 19:29:48.746124	113	1	2026-11-20 17:00:00	2026-11-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.749491	2026-03-03 19:29:48.7495	114	1	2026-11-23 17:00:00	2026-11-23 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.753285	2026-03-03 19:29:48.753294	115	1	2026-11-25 17:00:00	2026-11-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.757065	2026-03-03 19:29:48.757074	116	1	2026-11-27 17:00:00	2026-11-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.760732	2026-03-03 19:29:48.760741	117	1	2026-11-30 17:00:00	2026-11-30 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.764954	2026-03-03 19:29:48.764965	118	1	2026-12-02 17:00:00	2026-12-02 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.769596	2026-03-03 19:29:48.769607	119	1	2026-12-04 17:00:00	2026-12-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.775201	2026-03-03 19:29:48.77522	120	1	2026-12-07 17:00:00	2026-12-07 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.780521	2026-03-03 19:29:48.780535	121	1	2026-12-09 17:00:00	2026-12-09 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.784657	2026-03-03 19:29:48.78467	122	1	2026-12-11 17:00:00	2026-12-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.789851	2026-03-03 19:29:48.789862	123	1	2026-12-14 17:00:00	2026-12-14 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.793904	2026-03-03 19:29:48.793915	124	1	2026-12-16 17:00:00	2026-12-16 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.798133	2026-03-03 19:29:48.798145	125	1	2026-12-18 17:00:00	2026-12-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.802516	2026-03-03 19:29:48.802527	126	1	2026-12-21 17:00:00	2026-12-21 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.806345	2026-03-03 19:29:48.806361	127	1	2026-12-23 17:00:00	2026-12-23 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.810534	2026-03-03 19:29:48.81055	128	1	2026-12-25 17:00:00	2026-12-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.814528	2026-03-03 19:29:48.814544	129	1	2026-12-28 17:00:00	2026-12-28 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.826099	2026-03-03 19:29:48.826123	130	1	2026-12-30 17:00:00	2026-12-30 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.834949	2026-03-03 19:29:48.834963	131	1	2027-01-01 17:00:00	2027-01-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.8459	2026-03-03 19:29:48.845918	132	1	2027-01-04 17:00:00	2027-01-04 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.849623	2026-03-03 19:29:48.849634	133	1	2027-01-06 17:00:00	2027-01-06 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.852957	2026-03-03 19:29:48.852968	134	1	2027-01-08 17:00:00	2027-01-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.864026	2026-03-03 19:29:48.864127	135	1	2027-01-11 17:00:00	2027-01-11 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.874837	2026-03-03 19:29:48.874859	136	1	2027-01-13 17:00:00	2027-01-13 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.880603	2026-03-03 19:29:48.880619	137	1	2027-01-15 17:00:00	2027-01-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.890854	2026-03-03 19:29:48.890872	138	1	2027-01-18 17:00:00	2027-01-18 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.894559	2026-03-03 19:29:48.89457	139	1	2027-01-20 17:00:00	2027-01-20 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.900595	2026-03-03 19:29:48.900611	140	1	2027-01-22 17:00:00	2027-01-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.90465	2026-03-03 19:29:48.904662	141	1	2027-01-25 17:00:00	2027-01-25 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.914119	2026-03-03 19:29:48.914144	142	1	2027-01-27 17:00:00	2027-01-27 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.920288	2026-03-03 19:29:48.92031	143	1	2027-01-29 17:00:00	2027-01-29 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.928681	2026-03-03 19:29:48.928693	144	1	2027-02-01 17:00:00	2027-02-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.946101	2026-03-03 19:29:48.946137	145	1	2027-02-03 17:00:00	2027-02-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.957484	2026-03-03 19:29:48.957504	146	1	2027-02-05 17:00:00	2027-02-05 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.962832	2026-03-03 19:29:48.962846	147	1	2027-02-08 17:00:00	2027-02-08 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.967506	2026-03-03 19:29:48.967516	148	1	2027-02-10 17:00:00	2027-02-10 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.971281	2026-03-03 19:29:48.971292	149	1	2027-02-12 17:00:00	2027-02-12 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.980935	2026-03-03 19:29:48.980949	150	1	2027-02-15 17:00:00	2027-02-15 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.987218	2026-03-03 19:29:48.987231	151	1	2027-02-17 17:00:00	2027-02-17 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.991454	2026-03-03 19:29:48.991469	152	1	2027-02-19 17:00:00	2027-02-19 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:48.999347	2026-03-03 19:29:48.999359	153	1	2027-02-22 17:00:00	2027-02-22 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:49.003262	2026-03-03 19:29:49.003275	154	1	2027-02-24 17:00:00	2027-02-24 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:49.011655	2026-03-03 19:29:49.011681	155	1	2027-02-26 17:00:00	2027-02-26 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:49.017126	2026-03-03 19:29:49.017141	156	1	2027-03-01 17:00:00	2027-03-01 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
2026-03-03 19:29:49.025398	2026-03-03 19:29:49.025424	157	1	2027-03-03 17:00:00	2027-03-03 18:30:00	TRAINING		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	scheduled	\N	\N
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, amount, description, created_at, updated_at, title, category, date, created_by_id, marketing_campaign_id) FROM stdin;
\.


--
-- Data for Name: freeze_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.freeze_requests (id, student_id, requested_by_id, start_date, end_date, reason, file_url, status, created_at, processed_at, processed_by_id, updated_at) FROM stdin;
\.


--
-- Data for Name: funnel_stages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funnel_stages (id, key, title, color, "order", is_system, created_at, updated_at) FROM stdin;
1	new	Новый лид	bg-blue-500	0	t	2026-03-03 19:16:52.463156	2026-03-03 19:16:52.463204
2	call	Звонок	bg-yellow-500	1	t	2026-03-03 19:16:52.463213	2026-03-03 19:16:52.463221
3	trial	Первая тренировка	bg-purple-500	2	t	2026-03-03 19:16:52.463228	2026-03-03 19:16:52.463237
4	offer	Оффер	bg-indigo-500	3	t	2026-03-03 19:16:52.463244	2026-03-03 19:16:52.463248
5	deal	Сделка	bg-green-500	4	t	2026-03-03 19:16:52.463253	2026-03-03 19:16:52.463256
6	success	Успех	bg-emerald-600	5	t	2026-03-03 19:16:52.463259	2026-03-03 19:16:52.463262
7	reject	Отказ	bg-red-500	6	t	2026-03-03 19:16:52.463265	2026-03-03 19:16:52.463268
\.


--
-- Data for Name: generated_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generated_events (id, template_id, event_id, original_date, is_modified, is_cancelled, created_at, updated_at) FROM stdin;
1	1	1	2026-03-04 17:00:00	f	f	2026-03-03 19:29:48.203634	2026-03-03 19:29:48.20365
2	1	2	2026-03-06 17:00:00	f	f	2026-03-03 19:29:48.212706	2026-03-03 19:29:48.212719
3	1	3	2026-03-09 17:00:00	f	f	2026-03-03 19:29:48.218699	2026-03-03 19:29:48.218714
4	1	4	2026-03-11 17:00:00	f	f	2026-03-03 19:29:48.223895	2026-03-03 19:29:48.223904
5	1	5	2026-03-13 17:00:00	f	f	2026-03-03 19:29:48.229703	2026-03-03 19:29:48.229715
6	1	6	2026-03-16 17:00:00	f	f	2026-03-03 19:29:48.23518	2026-03-03 19:29:48.235193
7	1	7	2026-03-18 17:00:00	f	f	2026-03-03 19:29:48.240531	2026-03-03 19:29:48.240544
8	1	8	2026-03-20 17:00:00	f	f	2026-03-03 19:29:48.245754	2026-03-03 19:29:48.245766
9	1	9	2026-03-23 17:00:00	f	f	2026-03-03 19:29:48.251439	2026-03-03 19:29:48.251451
10	1	10	2026-03-25 17:00:00	f	f	2026-03-03 19:29:48.256561	2026-03-03 19:29:48.256573
11	1	11	2026-03-27 17:00:00	f	f	2026-03-03 19:29:48.262633	2026-03-03 19:29:48.262646
12	1	12	2026-03-30 17:00:00	f	f	2026-03-03 19:29:48.275015	2026-03-03 19:29:48.275026
13	1	13	2026-04-01 17:00:00	f	f	2026-03-03 19:29:48.281997	2026-03-03 19:29:48.282009
14	1	14	2026-04-03 17:00:00	f	f	2026-03-03 19:29:48.288311	2026-03-03 19:29:48.288325
15	1	15	2026-04-06 17:00:00	f	f	2026-03-03 19:29:48.293958	2026-03-03 19:29:48.293969
16	1	16	2026-04-08 17:00:00	f	f	2026-03-03 19:29:48.299399	2026-03-03 19:29:48.299409
17	1	17	2026-04-10 17:00:00	f	f	2026-03-03 19:29:48.304926	2026-03-03 19:29:48.30494
18	1	18	2026-04-13 17:00:00	f	f	2026-03-03 19:29:48.310063	2026-03-03 19:29:48.310074
19	1	19	2026-04-15 17:00:00	f	f	2026-03-03 19:29:48.315205	2026-03-03 19:29:48.315213
20	1	20	2026-04-17 17:00:00	f	f	2026-03-03 19:29:48.320191	2026-03-03 19:29:48.320205
21	1	21	2026-04-20 17:00:00	f	f	2026-03-03 19:29:48.326031	2026-03-03 19:29:48.326044
22	1	22	2026-04-22 17:00:00	f	f	2026-03-03 19:29:48.330883	2026-03-03 19:29:48.330895
23	1	23	2026-04-24 17:00:00	f	f	2026-03-03 19:29:48.335291	2026-03-03 19:29:48.335303
24	1	24	2026-04-27 17:00:00	f	f	2026-03-03 19:29:48.339914	2026-03-03 19:29:48.339924
25	1	25	2026-04-29 17:00:00	f	f	2026-03-03 19:29:48.34462	2026-03-03 19:29:48.344634
26	1	26	2026-05-01 17:00:00	f	f	2026-03-03 19:29:48.350662	2026-03-03 19:29:48.350676
27	1	27	2026-05-04 17:00:00	f	f	2026-03-03 19:29:48.356489	2026-03-03 19:29:48.356503
28	1	28	2026-05-06 17:00:00	f	f	2026-03-03 19:29:48.362445	2026-03-03 19:29:48.362459
29	1	29	2026-05-08 17:00:00	f	f	2026-03-03 19:29:48.368119	2026-03-03 19:29:48.368133
30	1	30	2026-05-11 17:00:00	f	f	2026-03-03 19:29:48.373561	2026-03-03 19:29:48.373574
31	1	31	2026-05-13 17:00:00	f	f	2026-03-03 19:29:48.379299	2026-03-03 19:29:48.379312
32	1	32	2026-05-15 17:00:00	f	f	2026-03-03 19:29:48.385206	2026-03-03 19:29:48.385219
33	1	33	2026-05-18 17:00:00	f	f	2026-03-03 19:29:48.391163	2026-03-03 19:29:48.391177
34	1	34	2026-05-20 17:00:00	f	f	2026-03-03 19:29:48.396569	2026-03-03 19:29:48.396582
35	1	35	2026-05-22 17:00:00	f	f	2026-03-03 19:29:48.402319	2026-03-03 19:29:48.402334
36	1	36	2026-05-25 17:00:00	f	f	2026-03-03 19:29:48.408543	2026-03-03 19:29:48.408556
37	1	37	2026-05-27 17:00:00	f	f	2026-03-03 19:29:48.414076	2026-03-03 19:29:48.414089
38	1	38	2026-05-29 17:00:00	f	f	2026-03-03 19:29:48.420468	2026-03-03 19:29:48.420482
39	1	39	2026-06-01 17:00:00	f	f	2026-03-03 19:29:48.426378	2026-03-03 19:29:48.426393
40	1	40	2026-06-03 17:00:00	f	f	2026-03-03 19:29:48.432454	2026-03-03 19:29:48.432468
41	1	41	2026-06-05 17:00:00	f	f	2026-03-03 19:29:48.438452	2026-03-03 19:29:48.438466
42	1	42	2026-06-08 17:00:00	f	f	2026-03-03 19:29:48.444195	2026-03-03 19:29:48.444208
43	1	43	2026-06-10 17:00:00	f	f	2026-03-03 19:29:48.449945	2026-03-03 19:29:48.449958
44	1	44	2026-06-12 17:00:00	f	f	2026-03-03 19:29:48.45572	2026-03-03 19:29:48.455734
45	1	45	2026-06-15 17:00:00	f	f	2026-03-03 19:29:48.461746	2026-03-03 19:29:48.46176
46	1	46	2026-06-17 17:00:00	f	f	2026-03-03 19:29:48.467716	2026-03-03 19:29:48.467731
47	1	47	2026-06-19 17:00:00	f	f	2026-03-03 19:29:48.473663	2026-03-03 19:29:48.473677
48	1	48	2026-06-22 17:00:00	f	f	2026-03-03 19:29:48.479717	2026-03-03 19:29:48.479731
49	1	49	2026-06-24 17:00:00	f	f	2026-03-03 19:29:48.485333	2026-03-03 19:29:48.485347
50	1	50	2026-06-26 17:00:00	f	f	2026-03-03 19:29:48.491525	2026-03-03 19:29:48.491537
51	1	51	2026-06-29 17:00:00	f	f	2026-03-03 19:29:48.496282	2026-03-03 19:29:48.496293
52	1	52	2026-07-01 17:00:00	f	f	2026-03-03 19:29:48.499838	2026-03-03 19:29:48.499847
53	1	53	2026-07-03 17:00:00	f	f	2026-03-03 19:29:48.503641	2026-03-03 19:29:48.50365
54	1	54	2026-07-06 17:00:00	f	f	2026-03-03 19:29:48.507487	2026-03-03 19:29:48.507495
55	1	55	2026-07-08 17:00:00	f	f	2026-03-03 19:29:48.511267	2026-03-03 19:29:48.511277
56	1	56	2026-07-10 17:00:00	f	f	2026-03-03 19:29:48.515452	2026-03-03 19:29:48.515465
57	1	57	2026-07-13 17:00:00	f	f	2026-03-03 19:29:48.519622	2026-03-03 19:29:48.51963
58	1	58	2026-07-15 17:00:00	f	f	2026-03-03 19:29:48.523238	2026-03-03 19:29:48.523246
59	1	59	2026-07-17 17:00:00	f	f	2026-03-03 19:29:48.527159	2026-03-03 19:29:48.527168
60	1	60	2026-07-20 17:00:00	f	f	2026-03-03 19:29:48.530648	2026-03-03 19:29:48.530661
61	1	61	2026-07-22 17:00:00	f	f	2026-03-03 19:29:48.534875	2026-03-03 19:29:48.534884
62	1	62	2026-07-24 17:00:00	f	f	2026-03-03 19:29:48.540383	2026-03-03 19:29:48.540395
63	1	63	2026-07-27 17:00:00	f	f	2026-03-03 19:29:48.545702	2026-03-03 19:29:48.545716
64	1	64	2026-07-29 17:00:00	f	f	2026-03-03 19:29:48.550705	2026-03-03 19:29:48.550719
65	1	65	2026-07-31 17:00:00	f	f	2026-03-03 19:29:48.55592	2026-03-03 19:29:48.555935
66	1	66	2026-08-03 17:00:00	f	f	2026-03-03 19:29:48.561449	2026-03-03 19:29:48.561462
67	1	67	2026-08-05 17:00:00	f	f	2026-03-03 19:29:48.566451	2026-03-03 19:29:48.566462
68	1	68	2026-08-07 17:00:00	f	f	2026-03-03 19:29:48.571108	2026-03-03 19:29:48.571123
69	1	69	2026-08-10 17:00:00	f	f	2026-03-03 19:29:48.575972	2026-03-03 19:29:48.575988
70	1	70	2026-08-12 17:00:00	f	f	2026-03-03 19:29:48.587422	2026-03-03 19:29:48.587465
71	1	71	2026-08-14 17:00:00	f	f	2026-03-03 19:29:48.593569	2026-03-03 19:29:48.593578
72	1	72	2026-08-17 17:00:00	f	f	2026-03-03 19:29:48.596933	2026-03-03 19:29:48.596941
73	1	73	2026-08-19 17:00:00	f	f	2026-03-03 19:29:48.600244	2026-03-03 19:29:48.600253
74	1	74	2026-08-21 17:00:00	f	f	2026-03-03 19:29:48.604849	2026-03-03 19:29:48.604858
75	1	75	2026-08-24 17:00:00	f	f	2026-03-03 19:29:48.608526	2026-03-03 19:29:48.608534
76	1	76	2026-08-26 17:00:00	f	f	2026-03-03 19:29:48.612423	2026-03-03 19:29:48.612432
77	1	77	2026-08-28 17:00:00	f	f	2026-03-03 19:29:48.616007	2026-03-03 19:29:48.616015
78	1	78	2026-08-31 17:00:00	f	f	2026-03-03 19:29:48.619356	2026-03-03 19:29:48.619364
79	1	79	2026-09-02 17:00:00	f	f	2026-03-03 19:29:48.622719	2026-03-03 19:29:48.622727
80	1	80	2026-09-04 17:00:00	f	f	2026-03-03 19:29:48.626836	2026-03-03 19:29:48.626846
81	1	81	2026-09-07 17:00:00	f	f	2026-03-03 19:29:48.630771	2026-03-03 19:29:48.630779
82	1	82	2026-09-09 17:00:00	f	f	2026-03-03 19:29:48.634669	2026-03-03 19:29:48.63468
83	1	83	2026-09-11 17:00:00	f	f	2026-03-03 19:29:48.638459	2026-03-03 19:29:48.638468
84	1	84	2026-09-14 17:00:00	f	f	2026-03-03 19:29:48.642004	2026-03-03 19:29:48.642012
85	1	85	2026-09-16 17:00:00	f	f	2026-03-03 19:29:48.645387	2026-03-03 19:29:48.645395
86	1	86	2026-09-18 17:00:00	f	f	2026-03-03 19:29:48.649047	2026-03-03 19:29:48.649056
87	1	87	2026-09-21 17:00:00	f	f	2026-03-03 19:29:48.652417	2026-03-03 19:29:48.652426
88	1	88	2026-09-23 17:00:00	f	f	2026-03-03 19:29:48.656812	2026-03-03 19:29:48.656822
89	1	89	2026-09-25 17:00:00	f	f	2026-03-03 19:29:48.660157	2026-03-03 19:29:48.660165
90	1	90	2026-09-28 17:00:00	f	f	2026-03-03 19:29:48.663507	2026-03-03 19:29:48.663515
91	1	91	2026-09-30 17:00:00	f	f	2026-03-03 19:29:48.666665	2026-03-03 19:29:48.666673
92	1	92	2026-10-02 17:00:00	f	f	2026-03-03 19:29:48.670747	2026-03-03 19:29:48.670756
93	1	93	2026-10-05 17:00:00	f	f	2026-03-03 19:29:48.674517	2026-03-03 19:29:48.674528
94	1	94	2026-10-07 17:00:00	f	f	2026-03-03 19:29:48.678835	2026-03-03 19:29:48.678845
95	1	95	2026-10-09 17:00:00	f	f	2026-03-03 19:29:48.682961	2026-03-03 19:29:48.68297
96	1	96	2026-10-12 17:00:00	f	f	2026-03-03 19:29:48.686302	2026-03-03 19:29:48.68631
97	1	97	2026-10-14 17:00:00	f	f	2026-03-03 19:29:48.689732	2026-03-03 19:29:48.689741
98	1	98	2026-10-16 17:00:00	f	f	2026-03-03 19:29:48.693227	2026-03-03 19:29:48.693235
99	1	99	2026-10-19 17:00:00	f	f	2026-03-03 19:29:48.696509	2026-03-03 19:29:48.696518
100	1	100	2026-10-21 17:00:00	f	f	2026-03-03 19:29:48.699749	2026-03-03 19:29:48.699758
101	1	101	2026-10-23 17:00:00	f	f	2026-03-03 19:29:48.703054	2026-03-03 19:29:48.703062
102	1	102	2026-10-26 17:00:00	f	f	2026-03-03 19:29:48.70636	2026-03-03 19:29:48.706368
103	1	103	2026-10-28 17:00:00	f	f	2026-03-03 19:29:48.709784	2026-03-03 19:29:48.709817
104	1	104	2026-10-30 17:00:00	f	f	2026-03-03 19:29:48.713241	2026-03-03 19:29:48.713249
105	1	105	2026-11-02 17:00:00	f	f	2026-03-03 19:29:48.718465	2026-03-03 19:29:48.718479
106	1	106	2026-11-04 17:00:00	f	f	2026-03-03 19:29:48.723663	2026-03-03 19:29:48.723678
107	1	107	2026-11-06 17:00:00	f	f	2026-03-03 19:29:48.728277	2026-03-03 19:29:48.728289
108	1	108	2026-11-09 17:00:00	f	f	2026-03-03 19:29:48.731936	2026-03-03 19:29:48.731944
109	1	109	2026-11-11 17:00:00	f	f	2026-03-03 19:29:48.735995	2026-03-03 19:29:48.736004
110	1	110	2026-11-13 17:00:00	f	f	2026-03-03 19:29:48.739825	2026-03-03 19:29:48.739835
111	1	111	2026-11-16 17:00:00	f	f	2026-03-03 19:29:48.743654	2026-03-03 19:29:48.743663
112	1	112	2026-11-18 17:00:00	f	f	2026-03-03 19:29:48.74683	2026-03-03 19:29:48.74684
113	1	113	2026-11-20 17:00:00	f	f	2026-03-03 19:29:48.750279	2026-03-03 19:29:48.750291
114	1	114	2026-11-23 17:00:00	f	f	2026-03-03 19:29:48.754049	2026-03-03 19:29:48.754058
115	1	115	2026-11-25 17:00:00	f	f	2026-03-03 19:29:48.757909	2026-03-03 19:29:48.757917
116	1	116	2026-11-27 17:00:00	f	f	2026-03-03 19:29:48.761711	2026-03-03 19:29:48.761719
117	1	117	2026-11-30 17:00:00	f	f	2026-03-03 19:29:48.76592	2026-03-03 19:29:48.765929
118	1	118	2026-12-02 17:00:00	f	f	2026-03-03 19:29:48.770547	2026-03-03 19:29:48.770561
119	1	119	2026-12-04 17:00:00	f	f	2026-03-03 19:29:48.776345	2026-03-03 19:29:48.776355
120	1	120	2026-12-07 17:00:00	f	f	2026-03-03 19:29:48.781423	2026-03-03 19:29:48.781432
121	1	121	2026-12-09 17:00:00	f	f	2026-03-03 19:29:48.786179	2026-03-03 19:29:48.786194
122	1	122	2026-12-11 17:00:00	f	f	2026-03-03 19:29:48.790695	2026-03-03 19:29:48.790703
123	1	123	2026-12-14 17:00:00	f	f	2026-03-03 19:29:48.794752	2026-03-03 19:29:48.794761
124	1	124	2026-12-16 17:00:00	f	f	2026-03-03 19:29:48.799033	2026-03-03 19:29:48.799045
125	1	125	2026-12-18 17:00:00	f	f	2026-03-03 19:29:48.803374	2026-03-03 19:29:48.803387
126	1	126	2026-12-21 17:00:00	f	f	2026-03-03 19:29:48.807227	2026-03-03 19:29:48.807236
127	1	127	2026-12-23 17:00:00	f	f	2026-03-03 19:29:48.811615	2026-03-03 19:29:48.811624
128	1	128	2026-12-25 17:00:00	f	f	2026-03-03 19:29:48.815342	2026-03-03 19:29:48.815356
129	1	129	2026-12-28 17:00:00	f	f	2026-03-03 19:29:48.827346	2026-03-03 19:29:48.82736
130	1	130	2026-12-30 17:00:00	f	f	2026-03-03 19:29:48.835846	2026-03-03 19:29:48.835855
131	1	131	2027-01-01 17:00:00	f	f	2026-03-03 19:29:48.846852	2026-03-03 19:29:48.846861
132	1	132	2027-01-04 17:00:00	f	f	2026-03-03 19:29:48.850347	2026-03-03 19:29:48.850356
133	1	133	2027-01-06 17:00:00	f	f	2026-03-03 19:29:48.853747	2026-03-03 19:29:48.853756
134	1	134	2027-01-08 17:00:00	f	f	2026-03-03 19:29:48.865809	2026-03-03 19:29:48.865824
135	1	135	2027-01-11 17:00:00	f	f	2026-03-03 19:29:48.876569	2026-03-03 19:29:48.876581
136	1	136	2027-01-13 17:00:00	f	f	2026-03-03 19:29:48.881647	2026-03-03 19:29:48.881655
137	1	137	2027-01-15 17:00:00	f	f	2026-03-03 19:29:48.891725	2026-03-03 19:29:48.891734
138	1	138	2027-01-18 17:00:00	f	f	2026-03-03 19:29:48.895349	2026-03-03 19:29:48.895357
139	1	139	2027-01-20 17:00:00	f	f	2026-03-03 19:29:48.90159	2026-03-03 19:29:48.901599
140	1	140	2027-01-22 17:00:00	f	f	2026-03-03 19:29:48.905474	2026-03-03 19:29:48.905483
141	1	141	2027-01-25 17:00:00	f	f	2026-03-03 19:29:48.91563	2026-03-03 19:29:48.915645
142	1	142	2027-01-27 17:00:00	f	f	2026-03-03 19:29:48.924717	2026-03-03 19:29:48.924742
143	1	143	2027-01-29 17:00:00	f	f	2026-03-03 19:29:48.932262	2026-03-03 19:29:48.932289
144	1	144	2027-02-01 17:00:00	f	f	2026-03-03 19:29:48.947225	2026-03-03 19:29:48.947233
145	1	145	2027-02-03 17:00:00	f	f	2026-03-03 19:29:48.95953	2026-03-03 19:29:48.95954
146	1	146	2027-02-05 17:00:00	f	f	2026-03-03 19:29:48.964544	2026-03-03 19:29:48.964554
147	1	147	2027-02-08 17:00:00	f	f	2026-03-03 19:29:48.96838	2026-03-03 19:29:48.968389
148	1	148	2027-02-10 17:00:00	f	f	2026-03-03 19:29:48.977035	2026-03-03 19:29:48.977052
149	1	149	2027-02-12 17:00:00	f	f	2026-03-03 19:29:48.981862	2026-03-03 19:29:48.981873
150	1	150	2027-02-15 17:00:00	f	f	2026-03-03 19:29:48.988344	2026-03-03 19:29:48.988365
151	1	151	2027-02-17 17:00:00	f	f	2026-03-03 19:29:48.994282	2026-03-03 19:29:48.994294
152	1	152	2027-02-19 17:00:00	f	f	2026-03-03 19:29:49.000214	2026-03-03 19:29:49.000223
153	1	153	2027-02-22 17:00:00	f	f	2026-03-03 19:29:49.004396	2026-03-03 19:29:49.004405
154	1	154	2027-02-24 17:00:00	f	f	2026-03-03 19:29:49.013026	2026-03-03 19:29:49.013038
155	1	155	2027-02-26 17:00:00	f	f	2026-03-03 19:29:49.018303	2026-03-03 19:29:49.018319
156	1	156	2027-03-01 17:00:00	f	f	2026-03-03 19:29:49.026625	2026-03-03 19:29:49.026634
157	1	157	2027-03-03 17:00:00	f	f	2026-03-03 19:29:49.028105	2026-03-03 19:29:49.028115
\.


--
-- Data for Name: group_chat_read_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_chat_read_status (id, user_id, group_id, last_read_at, created_at, updated_at) FROM stdin;
1	10	1	2026-03-03 19:56:28.635729	2026-03-03 19:38:08.384611	2026-03-03 19:56:28.637093
2	9	1	2026-03-03 20:23:15.961807	2026-03-03 20:20:45.085579	2026-03-03 20:23:15.964238
\.


--
-- Data for Name: group_coaches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_coaches (group_id, coach_id) FROM stdin;
1	9
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (created_at, updated_at, id, name, coach_id, max_capacity, deleted_at, deletion_reason, deleted_by_id, age_group, subscription_type, monthly_fee, classes_per_month, payment_due_day) FROM stdin;
2026-03-03 19:23:14.340983	2026-03-03 19:23:14.341039	1	U15	9	20	\N	\N	\N	2015	by_calendar	1200	8	10
\.


--
-- Data for Name: hr_candidates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hr_candidates (id, full_name, target_role, phone, email, experience_years, experience_summary, stage, next_interview_at, notes, resume_url, created_at, updated_at) FROM stdin;
1	eferferfef	Бухгалтер	e32423543r432		4		new	\N		\N	2026-03-03 17:24:00.756971+00	\N
2	Иванов Иван	Тренер	+37388888888		10		new	\N		\N	2026-03-03 17:32:53.451637+00	\N
3	иапипа	припаи	3424235425		\N		new	\N		\N	2026-03-03 18:08:51.705918+00	\N
4	Иван 	Тренер 	25886688588		1		new	\N		\N	2026-03-03 19:46:44.69217+00	\N
\.


--
-- Data for Name: hr_funnel_stages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hr_funnel_stages (id, key, title, color, "order", is_system, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, payment_id, item_type, description, quantity, unit_price, total_price, service_date, created_at, updated_at) FROM stdin;
1	1	membership	Абонемент за март 2026	1	1000	1000	2026-03-01 00:00:00	2026-03-03 20:06:36.950503	2026-03-03 20:06:36.950527
\.


--
-- Data for Name: lead_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_tasks (id, lead_id, title, due_date, completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leads (id, name, phone, age, next_contact_date, status, source, notes, rejection_reason, first_call_at, first_trial_at, created_at, updated_at, created_by_id, responsible_id) FROM stdin;
1	акая	453534532234	\N	\N	trial	other		\N	2026-03-03 18:07:30.452128	2026-03-03 18:08:28.41194	2026-03-03 18:07:27.488157	2026-03-03 18:08:28.417878	1	1
2	Поптос	2558569794	\N	\N	call			\N	2026-03-03 19:32:57.920395	\N	2026-03-03 19:32:33.096452	2026-03-03 19:32:57.923849	1	1
\.


--
-- Data for Name: marketing_campaigns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_campaigns (id, name, status, budget, spend, leads, paying_students, revenue, source, created_at, updated_at) FROM stdin;
1	dcdcd	preparing	0	0	0	0	0	Instagram	2026-03-03 19:23:37.294898	2026-03-03 19:28:20.722978
\.


--
-- Data for Name: media_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_reports (id, event_id, url, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (updated_at, id, sender_id, recipient_id, content, created_at, is_read, group_id, chat_type, is_pinned, poll_id, is_general) FROM stdin;
2026-03-03 19:29:49.051443	1	1	\N	📅 Расписание обновлено!\nГруппа: U15\nДобавлено 157 событий на период 03.03.2026 - 03.03.2027.\nПроверьте календарь.	2026-03-03 17:29:49.040593	f	1	schedule_notification	f	\N	t
2026-03-03 19:38:21.202964	2	10	\N	Привет	2026-03-03 19:38:21.199836	f	1	group_chat	f	\N	f
2026-03-03 19:56:28.393999	3	10	\N	Как	2026-03-03 19:56:28.383389	f	1	group_chat	f	\N	f
2026-03-03 20:00:03.351953	4	9	10	✅ Заявка на пропуск одобрена!\n👤 Ученик: Петя Иванов\n📅 Дата: 04.03.2026	2026-03-03 20:00:03.346232	f	\N	system	f	\N	f
2026-03-03 20:20:50.554259	5	9	\N	Нет	2026-03-03 20:20:50.550066	f	1	group_chat	f	\N	f
2026-03-03 20:21:53.217416	6	9	\N	Норок	2026-03-03 20:21:43.77551	t	\N	support	f	\N	f
2026-03-03 20:22:01.589196	7	1	9	привет	2026-03-03 20:22:01.586057	f	\N	support	f	\N	f
2026-03-03 20:22:26.133163	9	1	9	никэ	2026-03-03 20:22:26.126177	f	\N	support	f	\N	f
2026-03-03 20:22:26.214919	8	9	\N	Щи	2026-03-03 20:22:21.17228	t	\N	support	f	\N	f
2026-03-04 09:00:00.117887	10	1	\N	La mulți ani, Петя! 🎂🎉\nAstăzi sărbătorim ziua de naștere a lui Петя Иванов! \nEchipa Academiei vă dorește multă sănătate, fericire și succes în fotbal! ⚽🥅	2026-03-04 09:00:00.109493	f	1	group_chat	f	\N	f
2026-03-04 09:00:00.142666	11	1	10	La mulți ani, Петя! 🎂🎉\nAcademia vă felicită cu ocazia zilei de naștere! Vă dorim multe succese și realizări frumoase!	2026-03-04 09:00:00.141714	f	\N	system	f	\N	f
\.


--
-- Data for Name: payment_reminders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_reminders (id, student_id, reminder_type, sent_at, sent_via, target_month, amount_due, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (created_at, updated_at, id, student_id, amount, payment_date, payment_period, method, deleted_at, deletion_reason, deleted_by_id, last_student_name, status, description, reference_id) FROM stdin;
2026-03-03 20:06:36.933239	2026-03-03 20:06:36.933287	1	1	1000	2026-03-03	2026-03-01	cash	\N	\N	\N	\N	pending	Абонемент за март 2026	\N
\.


--
-- Data for Name: physical_tests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.physical_tests (id, name, description, unit, category, min_age, max_age, is_active, created_at, updated_at) FROM stdin;
1	Бег	Бег 100 метров 	М	speed	\N	\N	t	2026-03-03 18:11:59.624244	2026-03-03 20:13:06.427005
2	Тактик		Ум	technique	\N	\N	t	2026-03-03 18:15:33.783426	2026-03-03 20:15:33.783491
3	Стабильность 			discipline	\N	\N	t	2026-03-03 18:15:47.848487	2026-03-03 20:15:47.848595
4	Тактика 2			tactics	\N	\N	t	2026-03-03 18:16:21.402025	2026-03-03 20:16:21.402058
5	Физ			physical	\N	\N	t	2026-03-03 18:17:48.3638	2026-03-03 20:17:48.363855
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.poll_votes (id, poll_id, user_id, option_index, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.polls (id, creator_id, group_id, question, options, is_anonymous, is_multiple_choice, ends_at, created_at, is_closed, updated_at) FROM stdin;
\.


--
-- Data for Name: post_reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.post_reactions (id, post_id, user_id, reaction_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, author_id, group_id, post_type, title, content, media_urls, attachments, views_count, likes_count, is_pinned, is_published, created_at, updated_at, requires_confirmation, confirmation_deadline) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salary_payments (id, user_id, amount, payment_type, payment_date, period_month, period_year, method, status, description, reference_id, calculated_base, calculated_students, calculated_trainings, created_at, created_by_id, updated_at) FROM stdin;
1	9	2800	advance	2026-03-03	3	2026	cash	completed		\N	7000	1	12	2026-03-03 21:38:07.500397	1	2026-03-03 21:38:07.500469
2	11	2800	advance	2026-03-03	3	2026	cash	completed		\N	7000	0	0	2026-03-03 21:38:13.755928	1	2026-03-03 21:38:13.755981
3	1	2000	advance	2026-03-03	3	2026	cash	completed		\N	5000	0	0	2026-03-03 21:38:21.076531	1	2026-03-03 21:38:21.076603
\.


--
-- Data for Name: schedule_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_changes (id, event_id, group_id, change_type, reason, old_start_time, new_start_time, old_end_time, new_end_time, old_location, new_location, changed_by, notification_sent, notification_sent_at, parents_notified, coach_notified, sms_sent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schedule_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_templates (id, group_id, name, valid_from, valid_until, is_active, schedule_rules, excluded_dates, created_at, updated_at, created_by, deleted_at, deletion_reason, deleted_by_id) FROM stdin;
1	1	Расписание U15	2026-03-03 02:00:00	2027-03-03 02:00:00	t	[{"day": 0, "start_time": "17:00", "end_time": "18:30", "type": "TRAINING", "location": ""}, {"day": 2, "start_time": "17:00", "end_time": "18:30", "type": "TRAINING", "location": ""}, {"day": 4, "start_time": "17:00", "end_time": "18:30", "type": "TRAINING", "location": ""}]	[]	2026-03-03 19:29:38.428332	2026-03-03 19:29:53.562228	1	\N	\N	\N
\.


--
-- Data for Name: school_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.school_settings (key, value, description, "group", id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: season_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.season_summaries (id, student_id, season_year, gpa_technique, gpa_tactics, gpa_physical, gpa_discipline, total_gpa, created_at, updated_at, gpa_speed) FROM stdin;
1	1	2026	6	7	7	7	6.4	2026-03-03 20:11:23.666431	2026-03-03 20:11:23.66813	5
\.


--
-- Data for Name: student_group_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_group_history (id, student_id, group_id, joined_at, left_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_guardians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_guardians (created_at, updated_at, id, student_id, user_id, relationship_type) FROM stdin;
2026-03-03 19:34:49.871666	2026-03-03 19:34:49.871683	1	1	10	Parent
\.


--
-- Data for Name: student_photos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_photos (id, student_id, photo_url, thumbnail_url, caption, training_date, group_id, uploaded_by, is_profile_worthy, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_physical_test_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_physical_test_results (id, student_id, test_id, value, date, quarter, year, coach_id, created_at, updated_at) FROM stdin;
1	1	1	55	2026-03-03 20:13:58.572	1	2026	9	2026-03-03 18:13:58.629483	2026-03-03 18:13:58.629492
2	1	1	67	2026-03-03 20:14:29.395	2	2026	9	2026-03-03 18:14:09.792923	2026-03-03 18:14:29.471863
3	1	1	88	2026-03-03 20:14:40.104	3	2026	9	2026-03-03 18:14:40.187655	2026-03-03 18:14:40.187672
4	1	2	34	2026-03-03 20:16:34.079	1	2026	9	2026-03-03 18:16:34.127857	2026-03-03 18:16:34.12787
5	1	3	22	2026-03-03 20:16:45.434	1	2026	9	2026-03-03 18:16:45.498418	2026-03-03 18:16:45.498427
6	1	4	55	2026-03-03 20:16:52.305	1	2026	9	2026-03-03 18:16:52.351218	2026-03-03 18:16:52.351229
7	1	2	66	2026-03-03 20:17:03.162	2	2026	9	2026-03-03 18:17:03.211711	2026-03-03 18:17:03.211724
8	1	5	90	2026-03-03 20:17:59.712	1	2026	9	2026-03-03 18:17:59.762161	2026-03-03 18:17:59.762168
9	1	5	85	2026-03-03 20:18:57.189	2	2026	9	2026-03-03 18:18:57.245598	2026-03-03 18:18:57.245624
\.


--
-- Data for Name: student_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_skills (id, student_id, rating_month, rating_year, technique, discipline, coach_comment, rated_by_id, created_at, updated_at, tactics, physical, speed, talent_tags) FROM stdin;
1	1	3	2026	6	7		9	2026-03-03 18:11:23.645637	2026-03-03 18:11:23.645643	7	7	5	[]
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (created_at, updated_at, id, first_name, last_name, dob, group_id, avatar_url, status, balance, parent_phone, height, weight, total_paid_cache, cache_updated_at, blood_type, allergies, emergency_contact, emergency_phone, insurance_number, individual_fee, fee_discount_reason, deleted_at, deletion_reason, deleted_by_id, last_parent_name, last_parent_phone, last_group_name, medical_certificate_expires, insurance_expires, medical_certificate_file, shoe_size, medical_notes, attendance_streak, subscription_expires, is_debtor, is_frozen, freeze_until, freeze_document_url, medical_info, "position", dominant_foot, tshirt_size, notes, stars) FROM stdin;
2026-03-03 19:34:49.865143	2026-03-03 21:35:10.555552	1	Петя	Иванов	2015-03-04	1	/uploads/avatars/student_1_c6283783-f1cd-4338-9c87-3e40e1731dbb.JPG	active	-1000	+3731111111	135	35	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		1	\N	t	f	\N	\N		Вратарь	Правая			0
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, status, priority, due_date, assignee_id, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: training_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_plans (id, event_id, coach_id, objectives, theme, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trial_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trial_sessions (id, student_name, parent_name, parent_phone, parent_email, age, preferred_group_id, trial_date, status, source, notes, converted_student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_activity_logs (id, user_id, login_time, ip_address, user_agent, device_type, platform, created_at, updated_at) FROM stdin;
1	1	2026-03-03 17:06:58.233101	172.19.0.6	curl/7.81.0	desktop	unknown	2026-03-03 19:06:58.233146	2026-03-03 19:06:58.233205
2	1	2026-03-03 17:08:09.310641	172.19.0.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	desktop	macOS	2026-03-03 19:08:09.31068	2026-03-03 19:08:09.310729
3	1	2026-03-03 17:11:11.928398	172.19.0.6	curl/7.81.0	desktop	unknown	2026-03-03 19:11:11.928407	2026-03-03 19:11:11.928448
4	1	2026-03-03 17:16:14.074685	172.19.0.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Safari/605.1.15	desktop	macOS	2026-03-03 19:16:14.074722	2026-03-03 19:16:14.074777
5	1	2026-03-03 17:17:13.031538	172.19.0.6	curl/7.81.0	desktop	unknown	2026-03-03 19:17:13.031579	2026-03-03 19:17:13.031641
6	1	2026-03-03 17:21:32.314199	172.19.0.6	curl/7.81.0	desktop	unknown	2026-03-03 19:21:32.314235	2026-03-03 19:21:32.314284
7	10	2026-03-03 17:36:59.517005	172.19.0.6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/23D127 Safari/604.1	mobile	macOS	2026-03-03 19:36:59.517052	2026-03-03 19:36:59.517158
8	1	2026-03-03 17:42:26.199447	172.19.0.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	desktop	macOS	2026-03-03 19:42:26.199458	2026-03-03 19:42:26.199489
9	10	2026-03-03 17:59:08.310717	172.19.0.6	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/409.0.872648028 Mobile/15E148 Safari/604.1	mobile	macOS	2026-03-03 19:59:08.310784	2026-03-03 19:59:08.310905
10	9	2026-03-03 17:59:45.499059	172.19.0.6	Mozilla/5.0 (iPhone; CPU iPhone OS 26_3_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/409.0.872648028 Mobile/15E148 Safari/604.1	mobile	macOS	2026-03-03 19:59:45.499106	2026-03-03 19:59:45.499164
11	1	2026-03-03 19:27:20.445321	172.19.0.6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	mobile	macOS	2026-03-03 21:27:20.445357	2026-03-03 21:27:20.445439
12	1	2026-03-03 19:28:01.152136	172.19.0.6	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	mobile	macOS	2026-03-03 21:28:01.152173	2026-03-03 21:28:01.15225
\.


--
-- Data for Name: user_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_credentials (id, user_id, login, created_at, updated_at, created_by_id, updated_by_id, note, password_encrypted, last_viewed_at, last_viewed_by_id, view_count) FROM stdin;
3	9	+37333333333	2026-03-03 17:22:44.369201+00	2026-03-03 19:42:56.545749+00	1	1	Пароль обновлён администратором (Руководитель Sunny)	111111	2026-03-03 19:42:56.580719+00	1	3
4	10	+3731111111	2026-03-03 17:34:49.88059+00	2026-03-03 19:43:32.232734+00	1	\N	Создан 🏆 Спортивный директор: Руководитель Sunny	111111	2026-03-03 19:43:32.252973+00	1	3
5	11	+3735555555	2026-03-03 18:05:43.253296+00	2026-03-03 19:43:55.166413+00	1	\N	Создан 🏆 Спортивный директор: Руководитель Sunny	111111	2026-03-03 19:43:55.18687+00	1	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (created_at, updated_at, id, phone, password_hash, full_name, role, avatar_url, phone_secondary, preferred_language, is_active, fcm_token, deleted_at, deletion_reason, deleted_by_id, telegram_chat_id, can_view_history, can_view_analytics, can_view_crm, can_view_recruitment, can_view_marketing) FROM stdin;
2026-03-03 19:34:49.841355	2026-03-03 19:34:49.841755	10	+3731111111	$2b$12$nPGwAh6zTnwOC7cHkZnaSOLwZdHZiNS3VA3M2sKIFY3zbuSN1PeSK	Маша Иванова	parent	\N	\N	ru	t	\N	\N	\N	\N	\N	f	f	f	f	f
2026-03-03 20:05:43.232448	2026-03-03 20:05:43.232524	11	+3735555555	$2b$12$KFwr2dd0yR6ETRMms5asWOT0yqvLXagSqeTqKMABSCV2erNgjW0Ii	Админ 1	admin	\N	\N	ru	t	\N	\N	\N	\N	\N	f	f	f	f	f
2026-03-03 18:59:57.480704	2026-03-03 20:21:20.719851	1	+79777086823	$2b$12$n0VMRruczBy6HzIKvrbZSexYy9f01ZF1SzDgIdd3z1Jql/MwlBveq	Sunny	super_admin	/static/avatars/user_1_20260303_194213.jpg	\N	ru	t	\N	\N	\N	\N	\N	f	f	f	f	f
2026-03-03 19:22:44.348616	2026-03-03 20:23:27.825208	9	+37333333333	$2b$12$OEA8HgssTF1c1kiFrC9x4eiYPUf2G5Pz.s4FMT.MYVUsB0Cl/SBkO	Игорь Федорович	coach	/static/avatars/user_9_20260303_202030.jpeg	\N	ru	t	\N	\N	\N	\N	\N	f	f	f	f	f
\.


--
-- Name: absence_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.absence_requests_id_seq', 1, true);


--
-- Name: achievements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.achievements_id_seq', 1, false);


--
-- Name: announcement_reads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_reads_id_seq', 1, false);


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 15, true);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_seq', 1, false);


--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coach_recommendations_id_seq', 1, false);


--
-- Name: employee_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_contracts_id_seq', 3, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 157, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: freeze_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.freeze_requests_id_seq', 1, false);


--
-- Name: funnel_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funnel_stages_id_seq', 7, true);


--
-- Name: generated_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generated_events_id_seq', 157, true);


--
-- Name: group_chat_read_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.group_chat_read_status_id_seq', 2, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, true);


--
-- Name: hr_candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hr_candidates_id_seq', 4, true);


--
-- Name: hr_funnel_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hr_funnel_stages_id_seq', 1, false);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, true);


--
-- Name: lead_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_tasks_id_seq', 1, false);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leads_id_seq', 2, true);


--
-- Name: marketing_campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_campaigns_id_seq', 1, true);


--
-- Name: media_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_reports_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 13, true);


--
-- Name: payment_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_reminders_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, true);


--
-- Name: physical_tests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.physical_tests_id_seq', 5, true);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.poll_votes_id_seq', 1, false);


--
-- Name: polls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.polls_id_seq', 1, false);


--
-- Name: post_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_reactions_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 1, false);


--
-- Name: salary_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salary_payments_id_seq', 3, true);


--
-- Name: schedule_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_changes_id_seq', 1, false);


--
-- Name: schedule_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_templates_id_seq', 1, true);


--
-- Name: season_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.season_summaries_id_seq', 1, true);


--
-- Name: student_group_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_group_history_id_seq', 1, false);


--
-- Name: student_guardians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_guardians_id_seq', 1, true);


--
-- Name: student_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_photos_id_seq', 1, false);


--
-- Name: student_physical_test_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_physical_test_results_id_seq', 9, true);


--
-- Name: student_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_skills_id_seq', 1, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 1, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: training_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.training_plans_id_seq', 1, false);


--
-- Name: trial_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trial_sessions_id_seq', 1, false);


--
-- Name: user_activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_activity_logs_id_seq', 12, true);


--
-- Name: user_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_credentials_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: absence_requests absence_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_pkey PRIMARY KEY (id);


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: announcement_reads announcement_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: coach_recommendations coach_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_pkey PRIMARY KEY (id);


--
-- Name: employee_contracts employee_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: freeze_requests freeze_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_pkey PRIMARY KEY (id);


--
-- Name: funnel_stages funnel_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funnel_stages
    ADD CONSTRAINT funnel_stages_pkey PRIMARY KEY (id);


--
-- Name: generated_events generated_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_pkey PRIMARY KEY (id);


--
-- Name: group_chat_read_status group_chat_read_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_chat_read_status
    ADD CONSTRAINT group_chat_read_status_pkey PRIMARY KEY (id);


--
-- Name: group_coaches group_coaches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_coaches
    ADD CONSTRAINT group_coaches_pkey PRIMARY KEY (group_id, coach_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: hr_candidates hr_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_candidates
    ADD CONSTRAINT hr_candidates_pkey PRIMARY KEY (id);


--
-- Name: hr_funnel_stages hr_funnel_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hr_funnel_stages
    ADD CONSTRAINT hr_funnel_stages_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: lead_tasks lead_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tasks
    ADD CONSTRAINT lead_tasks_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: marketing_campaigns marketing_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT marketing_campaigns_pkey PRIMARY KEY (id);


--
-- Name: media_reports media_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_reports
    ADD CONSTRAINT media_reports_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payment_reminders payment_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders
    ADD CONSTRAINT payment_reminders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: physical_tests physical_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.physical_tests
    ADD CONSTRAINT physical_tests_pkey PRIMARY KEY (id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: post_reactions post_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: salary_payments salary_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_pkey PRIMARY KEY (id);


--
-- Name: schedule_changes schedule_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_pkey PRIMARY KEY (id);


--
-- Name: schedule_templates schedule_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_pkey PRIMARY KEY (id);


--
-- Name: school_settings school_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_settings
    ADD CONSTRAINT school_settings_pkey PRIMARY KEY (key, id);


--
-- Name: season_summaries season_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries
    ADD CONSTRAINT season_summaries_pkey PRIMARY KEY (id);


--
-- Name: student_group_history student_group_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_group_history
    ADD CONSTRAINT student_group_history_pkey PRIMARY KEY (id);


--
-- Name: student_guardians student_guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_pkey PRIMARY KEY (id);


--
-- Name: student_photos student_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_pkey PRIMARY KEY (id);


--
-- Name: student_physical_test_results student_physical_test_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_physical_test_results
    ADD CONSTRAINT student_physical_test_results_pkey PRIMARY KEY (id);


--
-- Name: student_skills student_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: training_plans training_plans_event_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT training_plans_event_id_key UNIQUE (event_id);


--
-- Name: training_plans training_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT training_plans_pkey PRIMARY KEY (id);


--
-- Name: trial_sessions trial_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_activity_logs user_activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs
    ADD CONSTRAINT user_activity_logs_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_attendance_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_student_id ON public.attendances USING btree (student_id);


--
-- Name: ix_absence_requests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_absence_requests_id ON public.absence_requests USING btree (id);


--
-- Name: ix_achievements_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_achievements_id ON public.achievements USING btree (id);


--
-- Name: ix_announcement_reads_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_announcement_reads_id ON public.announcement_reads USING btree (id);


--
-- Name: ix_attendance_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_event ON public.attendances USING btree (event_id);


--
-- Name: ix_attendance_student_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_student_event ON public.attendances USING btree (student_id, event_id);


--
-- Name: ix_attendance_student_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_student_status ON public.attendances USING btree (student_id, status);


--
-- Name: ix_attendances_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendances_id ON public.attendances USING btree (id);


--
-- Name: ix_audit_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: ix_audit_log_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- Name: ix_audit_log_entity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_entity_type ON public.audit_log USING btree (entity_type);


--
-- Name: ix_audit_log_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_id ON public.audit_log USING btree (id);


--
-- Name: ix_booking_coach_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_coach_date ON public.bookings USING btree (coach_id, booking_date);


--
-- Name: ix_booking_parent_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_parent_date ON public.bookings USING btree (parent_user_id, booking_date);


--
-- Name: ix_booking_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_status ON public.bookings USING btree (status);


--
-- Name: ix_bookings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_bookings_id ON public.bookings USING btree (id);


--
-- Name: ix_coach_recommendations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_coach_recommendations_id ON public.coach_recommendations USING btree (id);


--
-- Name: ix_contract_user_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_contract_user_active ON public.employee_contracts USING btree (user_id, is_active);


--
-- Name: ix_employee_contracts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_employee_contracts_id ON public.employee_contracts USING btree (id);


--
-- Name: ix_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_events_id ON public.events USING btree (id);


--
-- Name: ix_expense_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expense_category ON public.expenses USING btree (category);


--
-- Name: ix_expense_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expense_date ON public.expenses USING btree (date);


--
-- Name: ix_expenses_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_id ON public.expenses USING btree (id);


--
-- Name: ix_freeze_requests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_freeze_requests_id ON public.freeze_requests USING btree (id);


--
-- Name: ix_funnel_stages_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_funnel_stages_id ON public.funnel_stages USING btree (id);


--
-- Name: ix_funnel_stages_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_funnel_stages_key ON public.funnel_stages USING btree (key);


--
-- Name: ix_generated_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_generated_events_id ON public.generated_events USING btree (id);


--
-- Name: ix_group_chat_read_status_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_group_chat_read_status_id ON public.group_chat_read_status USING btree (id);


--
-- Name: ix_groups_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_groups_deleted_at ON public.groups USING btree (deleted_at);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_hr_candidates_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_hr_candidates_id ON public.hr_candidates USING btree (id);


--
-- Name: ix_hr_candidates_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_hr_candidates_stage ON public.hr_candidates USING btree (stage);


--
-- Name: ix_hr_funnel_stages_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_hr_funnel_stages_id ON public.hr_funnel_stages USING btree (id);


--
-- Name: ix_hr_funnel_stages_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_hr_funnel_stages_key ON public.hr_funnel_stages USING btree (key);


--
-- Name: ix_invoice_items_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoice_items_id ON public.invoice_items USING btree (id);


--
-- Name: ix_lead_tasks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lead_tasks_id ON public.lead_tasks USING btree (id);


--
-- Name: ix_lead_tasks_lead_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_lead_tasks_lead_id ON public.lead_tasks USING btree (lead_id);


--
-- Name: ix_leads_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_leads_id ON public.leads USING btree (id);


--
-- Name: ix_leads_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_leads_name ON public.leads USING btree (name);


--
-- Name: ix_leads_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_leads_phone ON public.leads USING btree (phone);


--
-- Name: ix_marketing_campaigns_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_marketing_campaigns_id ON public.marketing_campaigns USING btree (id);


--
-- Name: ix_marketing_campaigns_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_marketing_campaigns_status ON public.marketing_campaigns USING btree (status);


--
-- Name: ix_media_reports_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_media_reports_id ON public.media_reports USING btree (id);


--
-- Name: ix_messages_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_messages_id ON public.messages USING btree (id);


--
-- Name: ix_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_date ON public.salary_payments USING btree (payment_date);


--
-- Name: ix_payment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_deleted_at ON public.payments USING btree (deleted_at);


--
-- Name: ix_payment_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_period ON public.payments USING btree (payment_period);


--
-- Name: ix_payment_reminders_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_reminders_id ON public.payment_reminders USING btree (id);


--
-- Name: ix_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_status ON public.salary_payments USING btree (status);


--
-- Name: ix_payment_student_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_student_period ON public.payments USING btree (student_id, payment_period);


--
-- Name: ix_payment_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_user_period ON public.salary_payments USING btree (user_id, period_year, period_month);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_physical_tests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_physical_tests_id ON public.physical_tests USING btree (id);


--
-- Name: ix_poll_votes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_poll_votes_id ON public.poll_votes USING btree (id);


--
-- Name: ix_polls_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_polls_id ON public.polls USING btree (id);


--
-- Name: ix_post_reactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_post_reactions_id ON public.post_reactions USING btree (id);


--
-- Name: ix_posts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_posts_id ON public.posts USING btree (id);


--
-- Name: ix_push_subscriptions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_push_subscriptions_id ON public.push_subscriptions USING btree (id);


--
-- Name: ix_salary_payments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_salary_payments_id ON public.salary_payments USING btree (id);


--
-- Name: ix_schedule_changes_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_changes_group_id ON public.schedule_changes USING btree (group_id);


--
-- Name: ix_schedule_changes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_changes_id ON public.schedule_changes USING btree (id);


--
-- Name: ix_schedule_templates_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_templates_id ON public.schedule_templates USING btree (id);


--
-- Name: ix_school_settings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_school_settings_id ON public.school_settings USING btree (id);


--
-- Name: ix_school_settings_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_school_settings_key ON public.school_settings USING btree (key);


--
-- Name: ix_season_summaries_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_season_summaries_id ON public.season_summaries USING btree (id);


--
-- Name: ix_season_summaries_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_season_summaries_student_id ON public.season_summaries USING btree (student_id);


--
-- Name: ix_student_group_history_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_group_history_id ON public.student_group_history USING btree (id);


--
-- Name: ix_student_guardians_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_guardians_id ON public.student_guardians USING btree (id);


--
-- Name: ix_student_photos_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_photos_id ON public.student_photos USING btree (id);


--
-- Name: ix_student_physical_test_results_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_physical_test_results_id ON public.student_physical_test_results USING btree (id);


--
-- Name: ix_student_physical_test_results_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_physical_test_results_student_id ON public.student_physical_test_results USING btree (student_id);


--
-- Name: ix_student_skills_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_skills_id ON public.student_skills USING btree (id);


--
-- Name: ix_student_skills_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_skills_student_id ON public.student_skills USING btree (student_id);


--
-- Name: ix_students_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_students_deleted_at ON public.students USING btree (deleted_at);


--
-- Name: ix_students_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_students_id ON public.students USING btree (id);


--
-- Name: ix_tasks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_id ON public.tasks USING btree (id);


--
-- Name: ix_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_tasks_status ON public.tasks USING btree (status);


--
-- Name: ix_training_plans_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_training_plans_id ON public.training_plans USING btree (id);


--
-- Name: ix_trial_sessions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trial_sessions_id ON public.trial_sessions USING btree (id);


--
-- Name: ix_user_activity_logs_login_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_activity_logs_login_time ON public.user_activity_logs USING btree (login_time);


--
-- Name: ix_user_credentials_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_credentials_id ON public.user_credentials USING btree (id);


--
-- Name: ix_users_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_telegram_chat_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_chat_id ON public.users USING btree (telegram_chat_id);


--
-- Name: absence_requests absence_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: absence_requests absence_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: absence_requests absence_requests_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: achievements achievements_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_parent_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_parent_user_id_fkey FOREIGN KEY (parent_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: coach_recommendations coach_recommendations_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- Name: coach_recommendations coach_recommendations_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: employee_contracts employee_contracts_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: employee_contracts employee_contracts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: events events_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials fk_user_credentials_last_viewed_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT fk_user_credentials_last_viewed_by FOREIGN KEY (last_viewed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_processed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_processed_by_id_fkey FOREIGN KEY (processed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_requested_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_requested_by_id_fkey FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: generated_events generated_events_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: generated_events generated_events_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.schedule_templates(id) ON DELETE CASCADE;


--
-- Name: group_chat_read_status group_chat_read_status_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_chat_read_status
    ADD CONSTRAINT group_chat_read_status_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: group_chat_read_status group_chat_read_status_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_chat_read_status
    ADD CONSTRAINT group_chat_read_status_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_coaches group_coaches_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_coaches
    ADD CONSTRAINT group_coaches_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: group_coaches group_coaches_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_coaches
    ADD CONSTRAINT group_coaches_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: groups groups_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: groups groups_deleted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_deleted_by_id_fkey FOREIGN KEY (deleted_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoice_items invoice_items_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON DELETE CASCADE;


--
-- Name: lead_tasks lead_tasks_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tasks
    ADD CONSTRAINT lead_tasks_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: leads leads_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: leads leads_responsible_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_responsible_id_fkey FOREIGN KEY (responsible_id) REFERENCES public.users(id);


--
-- Name: media_reports media_reports_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_reports
    ADD CONSTRAINT media_reports_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: messages messages_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: messages messages_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE SET NULL;


--
-- Name: messages messages_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_reminders payment_reminders_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders
    ADD CONSTRAINT payment_reminders_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: payments payments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: polls polls_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: polls polls_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: post_reactions post_reactions_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_reactions post_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: salary_payments salary_payments_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: salary_payments salary_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedule_changes schedule_changes_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: schedule_changes schedule_changes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: schedule_changes schedule_changes_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: schedule_templates schedule_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedule_templates schedule_templates_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: season_summaries season_summaries_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries
    ADD CONSTRAINT season_summaries_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_group_history student_group_history_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_group_history
    ADD CONSTRAINT student_group_history_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: student_group_history student_group_history_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_group_history
    ADD CONSTRAINT student_group_history_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_photos student_photos_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: student_photos student_photos_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_photos student_photos_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: student_physical_test_results student_physical_test_results_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_physical_test_results
    ADD CONSTRAINT student_physical_test_results_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- Name: student_physical_test_results student_physical_test_results_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_physical_test_results
    ADD CONSTRAINT student_physical_test_results_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_physical_test_results student_physical_test_results_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_physical_test_results
    ADD CONSTRAINT student_physical_test_results_test_id_fkey FOREIGN KEY (test_id) REFERENCES public.physical_tests(id) ON DELETE CASCADE;


--
-- Name: student_skills student_skills_rated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_rated_by_id_fkey FOREIGN KEY (rated_by_id) REFERENCES public.users(id);


--
-- Name: student_skills student_skills_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: students students_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: training_plans training_plans_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT training_plans_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: training_plans training_plans_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT training_plans_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: trial_sessions trial_sessions_converted_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_converted_student_id_fkey FOREIGN KEY (converted_student_id) REFERENCES public.students(id);


--
-- Name: trial_sessions trial_sessions_preferred_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_preferred_group_id_fkey FOREIGN KEY (preferred_group_id) REFERENCES public.groups(id);


--
-- Name: user_activity_logs user_activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_activity_logs
    ADD CONSTRAINT user_activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_credentials user_credentials_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials user_credentials_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials user_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GNkzTv6r4IxEzEceiR8561LVXhUKLlcgxJ2SdEA1SL6wfA2rA5lokCvbzBXNAbS


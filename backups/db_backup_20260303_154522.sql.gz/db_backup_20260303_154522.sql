--
-- PostgreSQL database dump
--

\restrict fUgi8IMe13NaeNeY9G5FQHdxcOyksxWZb8NCf7NTVlDe5wIQ3otL9dNNsGh4z3n

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: attendancestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.attendancestatus AS ENUM (
    'PRESENT',
    'ABSENT',
    'SICK',
    'LATE'
);


ALTER TYPE public.attendancestatus OWNER TO postgres;

--
-- Name: bookingstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.bookingstatus AS ENUM (
    'pending',
    'confirmed',
    'cancelled',
    'completed'
);


ALTER TYPE public.bookingstatus OWNER TO postgres;

--
-- Name: chattype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.chattype AS ENUM (
    'announcement',
    'group_chat',
    'direct',
    'support',
    'schedule_notification',
    'system'
);


ALTER TYPE public.chattype OWNER TO postgres;

--
-- Name: eventtype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.eventtype AS ENUM (
    'TRAINING',
    'GAME',
    'MEDICAL'
);


ALTER TYPE public.eventtype OWNER TO postgres;

--
-- Name: paymentmethod; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.paymentmethod AS ENUM (
    'CASH',
    'CARD',
    'TRANSFER'
);


ALTER TYPE public.paymentmethod OWNER TO postgres;

--
-- Name: posttype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.posttype AS ENUM (
    'NEWS',
    'ANNOUNCEMENT',
    'SCHEDULE',
    'MATCH_REPORT',
    'EVENT'
);


ALTER TYPE public.posttype OWNER TO postgres;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.userrole AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'COACH',
    'PARENT'
);


ALTER TYPE public.userrole OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: absence_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.absence_requests (
    id integer NOT NULL,
    student_id integer NOT NULL,
    requested_by integer NOT NULL,
    absence_date date NOT NULL,
    reason character varying(500),
    status character varying(20),
    approved_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.absence_requests OWNER TO postgres;

--
-- Name: absence_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.absence_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.absence_requests_id_seq OWNER TO postgres;

--
-- Name: absence_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.absence_requests_id_seq OWNED BY public.absence_requests.id;


--
-- Name: achievements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.achievements (
    id integer NOT NULL,
    student_id integer,
    title character varying(200),
    description character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    icon character varying,
    type character varying,
    is_viewed boolean
);


ALTER TABLE public.achievements OWNER TO postgres;

--
-- Name: achievements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.achievements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.achievements_id_seq OWNER TO postgres;

--
-- Name: achievements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.achievements_id_seq OWNED BY public.achievements.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: announcement_reads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcement_reads (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    read_at timestamp without time zone,
    confirmed boolean,
    confirmed_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.announcement_reads OWNER TO postgres;

--
-- Name: announcement_reads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.announcement_reads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.announcement_reads_id_seq OWNER TO postgres;

--
-- Name: announcement_reads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.announcement_reads_id_seq OWNED BY public.announcement_reads.id;


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendances (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    event_id integer,
    student_id integer,
    status public.attendancestatus,
    mark integer,
    parent_rating integer,
    parent_feedback character varying(500)
);


ALTER TABLE public.attendances OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendances_id_seq OWNER TO postgres;

--
-- Name: attendances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendances_id_seq OWNED BY public.attendances.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer NOT NULL,
    entity_name character varying(255),
    action character varying(20) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_fields character varying[],
    user_id integer,
    user_name character varying(255),
    reason character varying(500),
    ip_address character varying(50),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    parent_user_id integer NOT NULL,
    student_id integer NOT NULL,
    coach_id integer,
    event_id integer,
    booking_date timestamp with time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    location character varying(200),
    status public.bookingstatus DEFAULT 'pending'::public.bookingstatus NOT NULL,
    notes text,
    parent_notes text,
    admin_notes text,
    price integer,
    is_paid integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bookings_id_seq OWNER TO postgres;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: coach_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coach_recommendations (
    id integer NOT NULL,
    student_id integer NOT NULL,
    coach_id integer NOT NULL,
    recommendation_type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    priority character varying(20),
    target_date date,
    is_completed boolean,
    completed_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.coach_recommendations OWNER TO postgres;

--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coach_recommendations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coach_recommendations_id_seq OWNER TO postgres;

--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coach_recommendations_id_seq OWNED BY public.coach_recommendations.id;


--
-- Name: employee_contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_contracts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    salary_type character varying DEFAULT 'fixed'::character varying,
    base_salary double precision DEFAULT '0'::double precision,
    per_student_rate double precision DEFAULT '0'::double precision,
    per_training_rate double precision DEFAULT '0'::double precision,
    advance_percent double precision DEFAULT '40'::double precision,
    advance_day integer DEFAULT 25,
    salary_day integer DEFAULT 10,
    effective_from date NOT NULL,
    effective_to date,
    is_active boolean DEFAULT true,
    notes character varying(500),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by_id integer,
    rates json
);


ALTER TABLE public.employee_contracts OWNER TO postgres;

--
-- Name: employee_contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_contracts_id_seq OWNER TO postgres;

--
-- Name: employee_contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_contracts_id_seq OWNED BY public.employee_contracts.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    group_id integer,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    type public.eventtype,
    location character varying,
    opponent_team character varying(200),
    home_away character varying(10),
    score_home integer,
    score_away integer,
    meeting_time timestamp without time zone,
    departure_time timestamp without time zone,
    transport_info character varying,
    uniform_color character varying(50),
    equipment_required character varying
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: COLUMN events.opponent_team; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.opponent_team IS 'Название команды противника';


--
-- Name: COLUMN events.home_away; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.home_away IS 'home/away/neutral';


--
-- Name: COLUMN events.score_home; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.score_home IS 'Наши голы';


--
-- Name: COLUMN events.score_away; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.score_away IS 'Голы противника';


--
-- Name: COLUMN events.meeting_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.meeting_time IS 'Время сбора команды';


--
-- Name: COLUMN events.departure_time; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.departure_time IS 'Время выезда';


--
-- Name: COLUMN events.transport_info; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.transport_info IS 'Информация о транспорте';


--
-- Name: COLUMN events.uniform_color; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.uniform_color IS 'Цвет формы (основная/запасная)';


--
-- Name: COLUMN events.equipment_required; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.events.equipment_required IS 'Необходимое оборудование';


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    amount double precision NOT NULL,
    description character varying(1000),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    title character varying(200) NOT NULL,
    category character varying,
    date date NOT NULL,
    created_by_id integer
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expenses_id_seq OWNER TO postgres;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: freeze_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.freeze_requests (
    id integer NOT NULL,
    student_id integer NOT NULL,
    requested_by_id integer,
    start_date date,
    end_date date NOT NULL,
    reason character varying(500),
    file_url character varying,
    status character varying,
    created_at timestamp without time zone,
    processed_at timestamp without time zone,
    processed_by_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.freeze_requests OWNER TO postgres;

--
-- Name: freeze_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.freeze_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.freeze_requests_id_seq OWNER TO postgres;

--
-- Name: freeze_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.freeze_requests_id_seq OWNED BY public.freeze_requests.id;


--
-- Name: generated_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generated_events (
    id integer NOT NULL,
    template_id integer NOT NULL,
    event_id integer NOT NULL,
    original_date timestamp without time zone NOT NULL,
    is_modified boolean,
    is_cancelled boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.generated_events OWNER TO postgres;

--
-- Name: generated_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generated_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generated_events_id_seq OWNER TO postgres;

--
-- Name: generated_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generated_events_id_seq OWNED BY public.generated_events.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    name character varying,
    coach_id integer,
    max_capacity integer,
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    updated_at timestamp without time zone,
    id integer NOT NULL,
    sender_id integer,
    recipient_id integer,
    content text NOT NULL,
    created_at timestamp without time zone,
    is_read boolean,
    group_id integer,
    chat_type public.chattype DEFAULT 'announcement'::public.chattype,
    is_pinned boolean,
    poll_id integer
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: payment_reminders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_reminders (
    id integer NOT NULL,
    student_id integer NOT NULL,
    reminder_type character varying(50) NOT NULL,
    sent_at timestamp without time zone,
    sent_via character varying(20) NOT NULL,
    target_month date NOT NULL,
    amount_due double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.payment_reminders OWNER TO postgres;

--
-- Name: payment_reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_reminders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_reminders_id_seq OWNER TO postgres;

--
-- Name: payment_reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payment_reminders_id_seq OWNED BY public.payment_reminders.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    student_id integer,
    amount double precision,
    payment_date date,
    payment_period date,
    method public.paymentmethod,
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    last_student_name character varying(255)
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: poll_votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.poll_votes (
    id integer NOT NULL,
    poll_id integer,
    user_id integer,
    option_index integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.poll_votes OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.poll_votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poll_votes_id_seq OWNER TO postgres;

--
-- Name: poll_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.poll_votes_id_seq OWNED BY public.poll_votes.id;


--
-- Name: polls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.polls (
    id integer NOT NULL,
    creator_id integer,
    group_id integer,
    question character varying(500) NOT NULL,
    options json NOT NULL,
    is_anonymous boolean,
    is_multiple_choice boolean,
    ends_at timestamp without time zone,
    created_at timestamp without time zone,
    is_closed boolean,
    updated_at timestamp without time zone
);


ALTER TABLE public.polls OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.polls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.polls_id_seq OWNER TO postgres;

--
-- Name: polls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.polls_id_seq OWNED BY public.polls.id;


--
-- Name: post_reactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.post_reactions (
    id integer NOT NULL,
    post_id integer,
    user_id integer,
    reaction_type character varying(20),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.post_reactions OWNER TO postgres;

--
-- Name: post_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.post_reactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_reactions_id_seq OWNER TO postgres;

--
-- Name: post_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.post_reactions_id_seq OWNED BY public.post_reactions.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    author_id integer,
    group_id integer,
    post_type public.posttype,
    title character varying(255),
    content text NOT NULL,
    media_urls json,
    attachments json,
    views_count integer,
    likes_count integer,
    is_pinned boolean,
    is_published boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    requires_confirmation boolean,
    confirmation_deadline timestamp without time zone
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.push_subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    endpoint text NOT NULL,
    p256dh character varying NOT NULL,
    auth character varying NOT NULL,
    user_agent character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.push_subscriptions OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.push_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.push_subscriptions_id_seq OWNER TO postgres;

--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.push_subscriptions_id_seq OWNED BY public.push_subscriptions.id;


--
-- Name: salary_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salary_payments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount double precision NOT NULL,
    payment_type character varying DEFAULT 'salary'::character varying,
    payment_date date NOT NULL,
    period_month integer NOT NULL,
    period_year integer NOT NULL,
    method character varying DEFAULT 'cash'::character varying,
    status character varying DEFAULT 'completed'::character varying,
    description character varying(500),
    reference_id character varying(100),
    calculated_base double precision,
    calculated_students integer,
    calculated_trainings integer,
    created_at timestamp without time zone,
    created_by_id integer,
    updated_at timestamp without time zone
);


ALTER TABLE public.salary_payments OWNER TO postgres;

--
-- Name: salary_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salary_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.salary_payments_id_seq OWNER TO postgres;

--
-- Name: salary_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salary_payments_id_seq OWNED BY public.salary_payments.id;


--
-- Name: schedule_changes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_changes (
    id integer NOT NULL,
    event_id integer,
    group_id integer NOT NULL,
    change_type character varying(30) NOT NULL,
    reason character varying(500) NOT NULL,
    old_start_time timestamp without time zone,
    new_start_time timestamp without time zone,
    old_end_time timestamp without time zone,
    new_end_time timestamp without time zone,
    old_location character varying(200),
    new_location character varying(200),
    changed_by integer,
    notification_sent boolean,
    notification_sent_at timestamp without time zone,
    parents_notified integer,
    coach_notified boolean,
    sms_sent boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.schedule_changes OWNER TO postgres;

--
-- Name: schedule_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_changes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_changes_id_seq OWNER TO postgres;

--
-- Name: schedule_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_changes_id_seq OWNED BY public.schedule_changes.id;


--
-- Name: schedule_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule_templates (
    id integer NOT NULL,
    group_id integer NOT NULL,
    name character varying(100) NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_until timestamp without time zone NOT NULL,
    is_active boolean,
    schedule_rules json NOT NULL,
    excluded_dates json,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    created_by integer
);


ALTER TABLE public.schedule_templates OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_templates_id_seq OWNER TO postgres;

--
-- Name: schedule_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_templates_id_seq OWNED BY public.schedule_templates.id;


--
-- Name: school_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.school_settings (
    key character varying(100) NOT NULL,
    value text,
    description character varying(255),
    "group" character varying(50),
    id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.school_settings OWNER TO postgres;

--
-- Name: season_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.season_summaries (
    id integer NOT NULL,
    student_id integer NOT NULL,
    season_year integer NOT NULL,
    gpa_technique double precision,
    gpa_tactics double precision,
    gpa_physical double precision,
    gpa_discipline double precision,
    total_gpa double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    gpa_speed double precision
);


ALTER TABLE public.season_summaries OWNER TO postgres;

--
-- Name: season_summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.season_summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.season_summaries_id_seq OWNER TO postgres;

--
-- Name: season_summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.season_summaries_id_seq OWNED BY public.season_summaries.id;


--
-- Name: student_guardians; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_guardians (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    student_id integer,
    user_id integer,
    relationship_type character varying
);


ALTER TABLE public.student_guardians OWNER TO postgres;

--
-- Name: student_guardians_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_guardians_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_guardians_id_seq OWNER TO postgres;

--
-- Name: student_guardians_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_guardians_id_seq OWNED BY public.student_guardians.id;


--
-- Name: student_photos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_photos (
    id integer NOT NULL,
    student_id integer NOT NULL,
    photo_url character varying(500) NOT NULL,
    thumbnail_url character varying(500),
    caption character varying(500),
    training_date date,
    group_id integer,
    uploaded_by integer,
    is_profile_worthy boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.student_photos OWNER TO postgres;

--
-- Name: student_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_photos_id_seq OWNER TO postgres;

--
-- Name: student_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_photos_id_seq OWNED BY public.student_photos.id;


--
-- Name: student_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_skills (
    id integer NOT NULL,
    student_id integer NOT NULL,
    rating_month integer NOT NULL,
    rating_year integer NOT NULL,
    technique integer,
    discipline integer,
    coach_comment text,
    rated_by_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tactics integer,
    physical integer,
    speed integer
);


ALTER TABLE public.student_skills OWNER TO postgres;

--
-- Name: student_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_skills_id_seq OWNER TO postgres;

--
-- Name: student_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_skills_id_seq OWNED BY public.student_skills.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    first_name character varying,
    last_name character varying,
    dob date,
    group_id integer,
    avatar_url character varying,
    status character varying,
    balance double precision,
    parent_phone character varying,
    height double precision,
    weight double precision,
    total_paid_cache double precision DEFAULT '0'::double precision,
    cache_updated_at timestamp without time zone,
    blood_type character varying(10),
    allergies text,
    emergency_contact character varying(100),
    emergency_phone character varying(20),
    insurance_number character varying(50),
    individual_fee double precision,
    fee_discount_reason character varying(255),
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    last_parent_name character varying(255),
    last_parent_phone character varying(50),
    last_group_name character varying(255),
    medical_certificate_expires date,
    insurance_expires date,
    medical_certificate_file character varying,
    shoe_size character varying,
    medical_notes text,
    attendance_streak integer
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.students_id_seq OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: trial_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trial_sessions (
    id integer NOT NULL,
    student_name character varying(200) NOT NULL,
    parent_name character varying(200),
    parent_phone character varying(20) NOT NULL,
    parent_email character varying(100),
    age integer,
    preferred_group_id integer,
    trial_date date NOT NULL,
    status character varying(30),
    source character varying(50),
    notes text,
    converted_student_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.trial_sessions OWNER TO postgres;

--
-- Name: trial_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trial_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trial_sessions_id_seq OWNER TO postgres;

--
-- Name: trial_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trial_sessions_id_seq OWNED BY public.trial_sessions.id;


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_credentials (
    id integer NOT NULL,
    user_id integer NOT NULL,
    login character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    created_by_id integer,
    updated_by_id integer,
    note text,
    password_encrypted character varying(500) NOT NULL,
    last_viewed_at timestamp with time zone,
    last_viewed_by_id integer,
    view_count integer DEFAULT 0
);


ALTER TABLE public.user_credentials OWNER TO postgres;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_credentials_id_seq OWNER TO postgres;

--
-- Name: user_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_credentials_id_seq OWNED BY public.user_credentials.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    id integer NOT NULL,
    phone character varying,
    password_hash character varying,
    full_name character varying,
    role public.userrole,
    avatar_url character varying,
    phone_secondary character varying,
    preferred_language character varying DEFAULT 'ro'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    fcm_token character varying(500),
    deleted_at timestamp without time zone,
    deletion_reason character varying(255),
    deleted_by_id integer,
    telegram_chat_id character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: absence_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests ALTER COLUMN id SET DEFAULT nextval('public.absence_requests_id_seq'::regclass);


--
-- Name: achievements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements ALTER COLUMN id SET DEFAULT nextval('public.achievements_id_seq'::regclass);


--
-- Name: announcement_reads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads ALTER COLUMN id SET DEFAULT nextval('public.announcement_reads_id_seq'::regclass);


--
-- Name: attendances id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances ALTER COLUMN id SET DEFAULT nextval('public.attendances_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: coach_recommendations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations ALTER COLUMN id SET DEFAULT nextval('public.coach_recommendations_id_seq'::regclass);


--
-- Name: employee_contracts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts ALTER COLUMN id SET DEFAULT nextval('public.employee_contracts_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: freeze_requests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests ALTER COLUMN id SET DEFAULT nextval('public.freeze_requests_id_seq'::regclass);


--
-- Name: generated_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events ALTER COLUMN id SET DEFAULT nextval('public.generated_events_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: payment_reminders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders ALTER COLUMN id SET DEFAULT nextval('public.payment_reminders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: poll_votes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes ALTER COLUMN id SET DEFAULT nextval('public.poll_votes_id_seq'::regclass);


--
-- Name: polls id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls ALTER COLUMN id SET DEFAULT nextval('public.polls_id_seq'::regclass);


--
-- Name: post_reactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions ALTER COLUMN id SET DEFAULT nextval('public.post_reactions_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: push_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.push_subscriptions_id_seq'::regclass);


--
-- Name: salary_payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments ALTER COLUMN id SET DEFAULT nextval('public.salary_payments_id_seq'::regclass);


--
-- Name: schedule_changes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes ALTER COLUMN id SET DEFAULT nextval('public.schedule_changes_id_seq'::regclass);


--
-- Name: schedule_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates ALTER COLUMN id SET DEFAULT nextval('public.schedule_templates_id_seq'::regclass);


--
-- Name: season_summaries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries ALTER COLUMN id SET DEFAULT nextval('public.season_summaries_id_seq'::regclass);


--
-- Name: student_guardians id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians ALTER COLUMN id SET DEFAULT nextval('public.student_guardians_id_seq'::regclass);


--
-- Name: student_photos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos ALTER COLUMN id SET DEFAULT nextval('public.student_photos_id_seq'::regclass);


--
-- Name: student_skills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills ALTER COLUMN id SET DEFAULT nextval('public.student_skills_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: trial_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions ALTER COLUMN id SET DEFAULT nextval('public.trial_sessions_id_seq'::regclass);


--
-- Name: user_credentials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials ALTER COLUMN id SET DEFAULT nextval('public.user_credentials_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: absence_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.absence_requests (id, student_id, requested_by, absence_date, reason, status, approved_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.achievements (id, student_id, title, description, created_at, updated_at, icon, type, is_viewed) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
1a2b3c4d5e6f
\.


--
-- Data for Name: announcement_reads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcement_reads (id, post_id, user_id, read_at, confirmed, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: attendances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendances (created_at, updated_at, id, event_id, student_id, status, mark, parent_rating, parent_feedback) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, entity_type, entity_id, entity_name, action, old_data, new_data, changed_fields, user_id, user_name, reason, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bookings (id, parent_user_id, student_id, coach_id, event_id, booking_date, duration_minutes, location, status, notes, parent_notes, admin_notes, price, is_paid, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coach_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coach_recommendations (id, student_id, coach_id, recommendation_type, title, description, priority, target_date, is_completed, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_contracts (id, user_id, salary_type, base_salary, per_student_rate, per_training_rate, advance_percent, advance_day, salary_day, effective_from, effective_to, is_active, notes, created_at, updated_at, created_by_id, rates) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (created_at, updated_at, id, group_id, start_time, end_time, type, location, opponent_team, home_away, score_home, score_away, meeting_time, departure_time, transport_info, uniform_color, equipment_required) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, amount, description, created_at, updated_at, title, category, date, created_by_id) FROM stdin;
\.


--
-- Data for Name: freeze_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.freeze_requests (id, student_id, requested_by_id, start_date, end_date, reason, file_url, status, created_at, processed_at, processed_by_id, updated_at) FROM stdin;
\.


--
-- Data for Name: generated_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generated_events (id, template_id, event_id, original_date, is_modified, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (created_at, updated_at, id, name, coach_id, max_capacity, deleted_at, deletion_reason, deleted_by_id) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (updated_at, id, sender_id, recipient_id, content, created_at, is_read, group_id, chat_type, is_pinned, poll_id) FROM stdin;
\.


--
-- Data for Name: payment_reminders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_reminders (id, student_id, reminder_type, sent_at, sent_via, target_month, amount_due, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (created_at, updated_at, id, student_id, amount, payment_date, payment_period, method, deleted_at, deletion_reason, deleted_by_id, last_student_name) FROM stdin;
\.


--
-- Data for Name: poll_votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.poll_votes (id, poll_id, user_id, option_index, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: polls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.polls (id, creator_id, group_id, question, options, is_anonymous, is_multiple_choice, ends_at, created_at, is_closed, updated_at) FROM stdin;
\.


--
-- Data for Name: post_reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.post_reactions (id, post_id, user_id, reaction_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, author_id, group_id, post_type, title, content, media_urls, attachments, views_count, likes_count, is_pinned, is_published, created_at, updated_at, requires_confirmation, confirmation_deadline) FROM stdin;
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.push_subscriptions (id, user_id, endpoint, p256dh, auth, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: salary_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salary_payments (id, user_id, amount, payment_type, payment_date, period_month, period_year, method, status, description, reference_id, calculated_base, calculated_students, calculated_trainings, created_at, created_by_id, updated_at) FROM stdin;
\.


--
-- Data for Name: schedule_changes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_changes (id, event_id, group_id, change_type, reason, old_start_time, new_start_time, old_end_time, new_end_time, old_location, new_location, changed_by, notification_sent, notification_sent_at, parents_notified, coach_notified, sms_sent, created_at) FROM stdin;
\.


--
-- Data for Name: schedule_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule_templates (id, group_id, name, valid_from, valid_until, is_active, schedule_rules, excluded_dates, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: school_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.school_settings (key, value, description, "group", id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: season_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.season_summaries (id, student_id, season_year, gpa_technique, gpa_tactics, gpa_physical, gpa_discipline, total_gpa, created_at, updated_at, gpa_speed) FROM stdin;
\.


--
-- Data for Name: student_guardians; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_guardians (created_at, updated_at, id, student_id, user_id, relationship_type) FROM stdin;
\.


--
-- Data for Name: student_photos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_photos (id, student_id, photo_url, thumbnail_url, caption, training_date, group_id, uploaded_by, is_profile_worthy, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_skills (id, student_id, rating_month, rating_year, technique, discipline, coach_comment, rated_by_id, created_at, updated_at, tactics, physical, speed) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (created_at, updated_at, id, first_name, last_name, dob, group_id, avatar_url, status, balance, parent_phone, height, weight, total_paid_cache, cache_updated_at, blood_type, allergies, emergency_contact, emergency_phone, insurance_number, individual_fee, fee_discount_reason, deleted_at, deletion_reason, deleted_by_id, last_parent_name, last_parent_phone, last_group_name, medical_certificate_expires, insurance_expires, medical_certificate_file, shoe_size, medical_notes, attendance_streak) FROM stdin;
\.


--
-- Data for Name: trial_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trial_sessions (id, student_name, parent_name, parent_phone, parent_email, age, preferred_group_id, trial_date, status, source, notes, converted_student_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_credentials (id, user_id, login, created_at, updated_at, created_by_id, updated_by_id, note, password_encrypted, last_viewed_at, last_viewed_by_id, view_count) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (created_at, updated_at, id, phone, password_hash, full_name, role, avatar_url, phone_secondary, preferred_language, is_active, fcm_token, deleted_at, deletion_reason, deleted_by_id, telegram_chat_id) FROM stdin;
\.


--
-- Name: absence_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.absence_requests_id_seq', 1, false);


--
-- Name: achievements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.achievements_id_seq', 1, false);


--
-- Name: announcement_reads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.announcement_reads_id_seq', 1, false);


--
-- Name: attendances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendances_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bookings_id_seq', 1, false);


--
-- Name: coach_recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coach_recommendations_id_seq', 1, false);


--
-- Name: employee_contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_contracts_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: freeze_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.freeze_requests_id_seq', 1, false);


--
-- Name: generated_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generated_events_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: payment_reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_reminders_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: poll_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.poll_votes_id_seq', 1, false);


--
-- Name: polls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.polls_id_seq', 1, false);


--
-- Name: post_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.post_reactions_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: push_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.push_subscriptions_id_seq', 1, false);


--
-- Name: salary_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salary_payments_id_seq', 1, false);


--
-- Name: schedule_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_changes_id_seq', 1, false);


--
-- Name: schedule_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_templates_id_seq', 1, false);


--
-- Name: season_summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.season_summaries_id_seq', 1, false);


--
-- Name: student_guardians_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_guardians_id_seq', 1, false);


--
-- Name: student_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_photos_id_seq', 1, false);


--
-- Name: student_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_skills_id_seq', 1, false);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 1, false);


--
-- Name: trial_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trial_sessions_id_seq', 1, false);


--
-- Name: user_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_credentials_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: absence_requests absence_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_pkey PRIMARY KEY (id);


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: announcement_reads announcement_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: coach_recommendations coach_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_pkey PRIMARY KEY (id);


--
-- Name: employee_contracts employee_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: freeze_requests freeze_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_pkey PRIMARY KEY (id);


--
-- Name: generated_events generated_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: payment_reminders payment_reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders
    ADD CONSTRAINT payment_reminders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: poll_votes poll_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_pkey PRIMARY KEY (id);


--
-- Name: polls polls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_pkey PRIMARY KEY (id);


--
-- Name: post_reactions post_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: salary_payments salary_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_pkey PRIMARY KEY (id);


--
-- Name: schedule_changes schedule_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_pkey PRIMARY KEY (id);


--
-- Name: schedule_templates schedule_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_pkey PRIMARY KEY (id);


--
-- Name: school_settings school_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_settings
    ADD CONSTRAINT school_settings_pkey PRIMARY KEY (key, id);


--
-- Name: season_summaries season_summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries
    ADD CONSTRAINT season_summaries_pkey PRIMARY KEY (id);


--
-- Name: student_guardians student_guardians_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_pkey PRIMARY KEY (id);


--
-- Name: student_photos student_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_pkey PRIMARY KEY (id);


--
-- Name: student_skills student_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: trial_sessions trial_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (id);


--
-- Name: user_credentials user_credentials_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_key UNIQUE (user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_attendance_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_student_id ON public.attendances USING btree (student_id);


--
-- Name: ix_absence_requests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_absence_requests_id ON public.absence_requests USING btree (id);


--
-- Name: ix_achievements_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_achievements_id ON public.achievements USING btree (id);


--
-- Name: ix_announcement_reads_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_announcement_reads_id ON public.announcement_reads USING btree (id);


--
-- Name: ix_attendance_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_event ON public.attendances USING btree (event_id);


--
-- Name: ix_attendance_student_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_student_event ON public.attendances USING btree (student_id, event_id);


--
-- Name: ix_attendance_student_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendance_student_status ON public.attendances USING btree (student_id, status);


--
-- Name: ix_attendances_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_attendances_id ON public.attendances USING btree (id);


--
-- Name: ix_audit_log_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: ix_audit_log_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- Name: ix_audit_log_entity_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_entity_type ON public.audit_log USING btree (entity_type);


--
-- Name: ix_audit_log_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_id ON public.audit_log USING btree (id);


--
-- Name: ix_booking_coach_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_coach_date ON public.bookings USING btree (coach_id, booking_date);


--
-- Name: ix_booking_parent_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_parent_date ON public.bookings USING btree (parent_user_id, booking_date);


--
-- Name: ix_booking_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_booking_status ON public.bookings USING btree (status);


--
-- Name: ix_bookings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_bookings_id ON public.bookings USING btree (id);


--
-- Name: ix_coach_recommendations_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_coach_recommendations_id ON public.coach_recommendations USING btree (id);


--
-- Name: ix_contract_user_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_contract_user_active ON public.employee_contracts USING btree (user_id, is_active);


--
-- Name: ix_employee_contracts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_employee_contracts_id ON public.employee_contracts USING btree (id);


--
-- Name: ix_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_events_id ON public.events USING btree (id);


--
-- Name: ix_expense_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expense_category ON public.expenses USING btree (category);


--
-- Name: ix_expense_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expense_date ON public.expenses USING btree (date);


--
-- Name: ix_expenses_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_id ON public.expenses USING btree (id);


--
-- Name: ix_freeze_requests_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_freeze_requests_id ON public.freeze_requests USING btree (id);


--
-- Name: ix_generated_events_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_generated_events_id ON public.generated_events USING btree (id);


--
-- Name: ix_groups_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_groups_deleted_at ON public.groups USING btree (deleted_at);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_messages_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_messages_id ON public.messages USING btree (id);


--
-- Name: ix_payment_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_date ON public.salary_payments USING btree (payment_date);


--
-- Name: ix_payment_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_deleted_at ON public.payments USING btree (deleted_at);


--
-- Name: ix_payment_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_period ON public.payments USING btree (payment_period);


--
-- Name: ix_payment_reminders_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_reminders_id ON public.payment_reminders USING btree (id);


--
-- Name: ix_payment_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_status ON public.salary_payments USING btree (status);


--
-- Name: ix_payment_student_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_student_period ON public.payments USING btree (student_id, payment_period);


--
-- Name: ix_payment_user_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_user_period ON public.salary_payments USING btree (user_id, period_year, period_month);


--
-- Name: ix_payments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payments_id ON public.payments USING btree (id);


--
-- Name: ix_poll_votes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_poll_votes_id ON public.poll_votes USING btree (id);


--
-- Name: ix_polls_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_polls_id ON public.polls USING btree (id);


--
-- Name: ix_post_reactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_post_reactions_id ON public.post_reactions USING btree (id);


--
-- Name: ix_posts_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_posts_id ON public.posts USING btree (id);


--
-- Name: ix_push_subscriptions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_push_subscriptions_id ON public.push_subscriptions USING btree (id);


--
-- Name: ix_salary_payments_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_salary_payments_id ON public.salary_payments USING btree (id);


--
-- Name: ix_schedule_changes_group_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_changes_group_id ON public.schedule_changes USING btree (group_id);


--
-- Name: ix_schedule_changes_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_changes_id ON public.schedule_changes USING btree (id);


--
-- Name: ix_schedule_templates_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_schedule_templates_id ON public.schedule_templates USING btree (id);


--
-- Name: ix_school_settings_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_school_settings_id ON public.school_settings USING btree (id);


--
-- Name: ix_school_settings_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_school_settings_key ON public.school_settings USING btree (key);


--
-- Name: ix_season_summaries_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_season_summaries_id ON public.season_summaries USING btree (id);


--
-- Name: ix_season_summaries_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_season_summaries_student_id ON public.season_summaries USING btree (student_id);


--
-- Name: ix_student_guardians_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_guardians_id ON public.student_guardians USING btree (id);


--
-- Name: ix_student_photos_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_photos_id ON public.student_photos USING btree (id);


--
-- Name: ix_student_skills_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_skills_id ON public.student_skills USING btree (id);


--
-- Name: ix_student_skills_student_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_student_skills_student_id ON public.student_skills USING btree (student_id);


--
-- Name: ix_students_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_students_deleted_at ON public.students USING btree (deleted_at);


--
-- Name: ix_students_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_students_id ON public.students USING btree (id);


--
-- Name: ix_trial_sessions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_trial_sessions_id ON public.trial_sessions USING btree (id);


--
-- Name: ix_user_credentials_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_user_credentials_id ON public.user_credentials USING btree (id);


--
-- Name: ix_users_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_phone ON public.users USING btree (phone);


--
-- Name: ix_users_telegram_chat_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_telegram_chat_id ON public.users USING btree (telegram_chat_id);


--
-- Name: absence_requests absence_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: absence_requests absence_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: absence_requests absence_requests_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.absence_requests
    ADD CONSTRAINT absence_requests_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: achievements achievements_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcement_reads
    ADD CONSTRAINT announcement_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: bookings bookings_parent_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_parent_user_id_fkey FOREIGN KEY (parent_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: coach_recommendations coach_recommendations_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- Name: coach_recommendations coach_recommendations_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_recommendations
    ADD CONSTRAINT coach_recommendations_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: employee_contracts employee_contracts_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: employee_contracts employee_contracts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_contracts
    ADD CONSTRAINT employee_contracts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: events events_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: expenses expenses_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials fk_user_credentials_last_viewed_by; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT fk_user_credentials_last_viewed_by FOREIGN KEY (last_viewed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_processed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_processed_by_id_fkey FOREIGN KEY (processed_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_requested_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_requested_by_id_fkey FOREIGN KEY (requested_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: freeze_requests freeze_requests_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freeze_requests
    ADD CONSTRAINT freeze_requests_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: generated_events generated_events_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: generated_events generated_events_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_events
    ADD CONSTRAINT generated_events_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.schedule_templates(id) ON DELETE CASCADE;


--
-- Name: groups groups_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: groups groups_deleted_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_deleted_by_id_fkey FOREIGN KEY (deleted_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: messages messages_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: messages messages_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE SET NULL;


--
-- Name: messages messages_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_reminders payment_reminders_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_reminders
    ADD CONSTRAINT payment_reminders_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: payments payments_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_poll_id_fkey FOREIGN KEY (poll_id) REFERENCES public.polls(id) ON DELETE CASCADE;


--
-- Name: poll_votes poll_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.poll_votes
    ADD CONSTRAINT poll_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: polls polls_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: polls polls_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.polls
    ADD CONSTRAINT polls_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: post_reactions post_reactions_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_reactions post_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.post_reactions
    ADD CONSTRAINT post_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: push_subscriptions push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: salary_payments salary_payments_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: salary_payments salary_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_payments
    ADD CONSTRAINT salary_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: schedule_changes schedule_changes_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: schedule_changes schedule_changes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: schedule_changes schedule_changes_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_changes
    ADD CONSTRAINT schedule_changes_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: schedule_templates schedule_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedule_templates schedule_templates_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule_templates
    ADD CONSTRAINT schedule_templates_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: season_summaries season_summaries_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.season_summaries
    ADD CONSTRAINT season_summaries_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_guardians student_guardians_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_guardians
    ADD CONSTRAINT student_guardians_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_photos student_photos_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: student_photos student_photos_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: student_photos student_photos_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_photos
    ADD CONSTRAINT student_photos_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: student_skills student_skills_rated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_rated_by_id_fkey FOREIGN KEY (rated_by_id) REFERENCES public.users(id);


--
-- Name: student_skills student_skills_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_skills
    ADD CONSTRAINT student_skills_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.students(id) ON DELETE CASCADE;


--
-- Name: students students_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE SET NULL;


--
-- Name: trial_sessions trial_sessions_converted_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_converted_student_id_fkey FOREIGN KEY (converted_student_id) REFERENCES public.students(id);


--
-- Name: trial_sessions trial_sessions_preferred_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trial_sessions
    ADD CONSTRAINT trial_sessions_preferred_group_id_fkey FOREIGN KEY (preferred_group_id) REFERENCES public.groups(id);


--
-- Name: user_credentials user_credentials_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials user_credentials_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_credentials user_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fUgi8IMe13NaeNeY9G5FQHdxcOyksxWZb8NCf7NTVlDe5wIQ3otL9dNNsGh4z3n

